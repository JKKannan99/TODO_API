package com.bankingsystem.bank.dto;
import lombok.Data;

@Data
public class ApiResponse {

    private String message;
    private boolean success;
    private String username;
    private Double balance;

    public ApiResponse(String message, boolean success, String username, Double balance) {
        this.message = message;
        this.success = success;
        this.username = username;
        this.balance = balance;
    }

    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getUsername() {
        return username;
    }

    public Double getBalance() {
        return balance;
    }
}