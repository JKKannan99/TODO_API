package com.bankingsystem.bank.service;

import com.bankingsystem.bank.dto.*;
import com.bankingsystem.bank.entity.User;
import com.bankingsystem.bank.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Register
    public ApiResponse register(RegisterRequest request){

        // Check if user already exists
        User existingUser = userRepository.findByUsername(request.getUsername());

        if (existingUser != null) {
            return new ApiResponse(

                    "Username already exists. Please try another.",
                    false,
                    null,
                    null
            );
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(request.getPassword());
        user.setBalance(0.0);

        String accountNumber = "ACC" + System.currentTimeMillis();
        user.setAccountNumber(accountNumber);

        userRepository.save(user);

        return new ApiResponse(
                "Registration successful for " + user.getUsername(),
                true,
                user.getAccountNumber(),
                user.getBalance()
        );
    }

    // Login
    public ApiResponse login(LoginRequest request){

        User user = userRepository.findByUsername(request.getUsername());

        if (user == null) {
            return new ApiResponse(
                    "User not found. Please register first.",
                    false,
                    null,
                    null
            );
        }

        if (!user.getPassword().equals(request.getPassword())) {
            return new ApiResponse(
                    "Invalid password.",
                    false,
                    null,
                    null
            );
        }

        return new ApiResponse(
                "Login successful.",
                true,
                user.getAccountNumber(),
                user.getBalance()
        );
    }

    // Deposit
    public ApiResponse deposit(TransactionRequest request) {

        User user = userRepository.findByAccountNumber(request.getAccountNumber());

        if (user == null) {
            return new ApiResponse(
                    "User not found. Please register first.",
                    false,
                    null,
                    null
            );
        }

        if (request.getAmount() <= 0) {
            return new ApiResponse(
                    "Deposit amount must be greater than 0.",
                    false,
                    null,
                    null
            );
        }

        user.setBalance(user.getBalance() + request.getAmount());
        userRepository.save(user);

        return new ApiResponse(
                "Cash successfully deposited.",
                true,
                user.getAccountNumber(),
                user.getBalance()
        );
    }

    // Withdraw
    public ApiResponse withdraw(TransactionRequest request) {

        User user = userRepository.findByAccountNumber(request.getAccountNumber());

        if (user == null) {
            return new ApiResponse(
                    "Invalid Account Number",
                    false,
                    null,
                    null
            );
        }

        if (request.getAmount() <= 0) {
            return new ApiResponse(
                    "Withdraw amount must be greater than 0.",
                    false,
                    null,
                    null
            );
        }

        if (user.getBalance() < request.getAmount()) {
            return new ApiResponse(
                    "Insufficient balance.",
                    false,
                    user.getUsername(),
                    user.getBalance()
            );
        }

        user.setBalance(user.getBalance() - request.getAmount());
        userRepository.save(user);

        return new ApiResponse(
                "Cash successfully withdrawn.",
                true,
                user.getAccountNumber(),
                user.getBalance()
        );
    }
}