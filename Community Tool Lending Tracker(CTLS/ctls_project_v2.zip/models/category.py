from sqlalchemy import Column, Integer, String, Text
from db import Base


class ToolCategory(Base):
    __tablename__ = "tool_categories"

    category_id = Column(Integer, primary_key=True, index=True)
    category_name = Column(String(50), nullable=False)
    description = Column(Text)
