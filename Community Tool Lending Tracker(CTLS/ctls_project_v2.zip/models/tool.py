from sqlalchemy import Column, Integer, String, Text, DECIMAL, DateTime, ForeignKey, func
from sqlalchemy.orm import relationship
from db import Base


class Tool(Base):
    """One row = one type of tool, with a quantity in stock
    (like a shop's inventory), not one row per physical item."""

    __tablename__ = "tools"

    tool_id = Column(Integer, primary_key=True, index=True)
    category_id = Column(Integer, ForeignKey("tool_categories.category_id"))
    tool_name = Column(String(100), nullable=False)
    description = Column(Text)
    condition_status = Column(String(20), default="GOOD")        # GOOD, FAIR, DAMAGED
    quantity_total = Column(Integer, default=1)
    quantity_available = Column(Integer, default=1)
    rental_per_day = Column(DECIMAL(10, 2), default=0)
    location = Column(String(100))
    status = Column(String(20), default="ACTIVE")                # ACTIVE, MAINTENANCE, DELETED
    created_by = Column(Integer, ForeignKey("users.user_id"))
    created_at = Column(DateTime, server_default=func.now())

    category = relationship("ToolCategory")
    added_by = relationship("User")
