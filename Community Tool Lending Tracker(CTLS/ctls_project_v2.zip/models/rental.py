from datetime import date

from sqlalchemy import Column, Integer, String, Date, DateTime, DECIMAL, ForeignKey, func
from sqlalchemy.orm import relationship
from db import Base


class Rental(Base):
    """One row = one tool rented out to one walk-in client.
    No approval step - staff creates this directly at the counter."""

    __tablename__ = "rentals"

    rental_id = Column(Integer, primary_key=True, index=True)
    tool_id = Column(Integer, ForeignKey("tools.tool_id"))
    quantity = Column(Integer, default=1)

    client_name = Column(String(100), nullable=False)
    client_address = Column(String(255))
    client_phone = Column(String(20), nullable=False)

    rented_by = Column(Integer, ForeignKey("users.user_id"))       # staff who handled it
    rental_date = Column(Date, default=date.today, nullable=False)
    expected_return_date = Column(Date, nullable=False)
    actual_return_date = Column(Date, nullable=True)

    rental_per_day = Column(DECIMAL(10, 2), nullable=False)         # snapshot of the rate at rental time
    rental_amount = Column(DECIMAL(10, 2), nullable=False)          # rate * quantity * planned days
    penalty_amount = Column(DECIMAL(10, 2), default=0)              # filled in on late return
    total_amount = Column(DECIMAL(10, 2), nullable=False)           # rental_amount (+ penalty)
    advance_amount = Column(DECIMAL(10, 2), default=0)
    amount_paid = Column(DECIMAL(10, 2), default=0)                 # running total incl. advance
    payment_status = Column(String(20), default="PENDING")          # PENDING, PARTIAL, PAID

    issue_condition = Column(String(20), default="GOOD")
    return_condition = Column(String(20), nullable=True)
    status = Column(String(20), default="DELIVERED")                # DELIVERED, RETURNED

    created_at = Column(DateTime, server_default=func.now())

    tool = relationship("Tool")
