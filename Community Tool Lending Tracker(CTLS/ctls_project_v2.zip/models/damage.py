from datetime import date

from sqlalchemy import Column, Integer, String, Text, Date, DECIMAL, ForeignKey, func
from sqlalchemy.orm import relationship
from db import Base


class DamageReport(Base):
    __tablename__ = "damage_reports"

    damage_id = Column(Integer, primary_key=True, index=True)
    rental_id = Column(Integer, ForeignKey("rentals.rental_id"))
    reported_by = Column(Integer, ForeignKey("users.user_id"))
    damage_description = Column(Text)
    severity = Column(String(20), default="MINOR")               # MINOR, MAJOR
    estimated_cost = Column(DECIMAL(10, 2), default=0)
    resolution_status = Column(String(20), default="OPEN")        # OPEN, RESOLVED
    reported_date = Column(Date, default=date.today, nullable=False)

    rental = relationship("Rental")
