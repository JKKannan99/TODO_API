from sqlalchemy import Column, Integer, String, DateTime, func
from db import Base


class User(Base):
    """One row = one staff login (ADMIN or MEMBER).
    Walk-in clients are NOT stored here - see models/rental.py,
    they are just plain text fields on a rental."""

    __tablename__ = "users"

    user_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    phone = Column(String(20))
    password = Column(String(100), nullable=False)   # plain text - teaching demo only!
    role = Column(String(20), default="MEMBER")        # ADMIN or MEMBER
    status = Column(String(20), default="ACTIVE")      # ACTIVE or BLOCKED
    created_at = Column(DateTime, server_default=func.now())
