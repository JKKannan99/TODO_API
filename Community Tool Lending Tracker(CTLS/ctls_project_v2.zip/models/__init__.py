"""
Importing every model here means main.py only has to do
`import models` once, and Base.metadata.create_all() will
know about ALL the tables below.
"""

from .user import User
from .category import ToolCategory
from .tool import Tool
from .rental import Rental
from .damage import DamageReport
