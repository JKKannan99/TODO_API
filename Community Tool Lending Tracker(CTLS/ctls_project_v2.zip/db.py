"""
db.py
-----
Sets up the connection to MySQL using SQLAlchemy.
Every file in models/ uses the Base defined here.
Every route uses get_db() to borrow a database session.

NOTE: the database itself must already exist. Run this once
in MySQL before starting the app:

    CREATE DATABASE ctls_db;

The tables inside it are created automatically by main.py on
startup (Base.metadata.create_all).
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Change the username/password below if yours is different.
# Format: mysql+pymysql://<user>:<password>@<host>/<database>
DATABASE_URL = "mysql+pymysql://root:root@localhost/ctls_db"

engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency - gives each request its own DB session
    and always closes it afterwards, even if an error happens."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
