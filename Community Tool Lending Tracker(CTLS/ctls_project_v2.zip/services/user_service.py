from fastapi import HTTPException
from models import User


def login(db, email, password):
    user = db.query(User).filter(User.email == email, User.password == password).first()
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if user.status != "ACTIVE":
        raise HTTPException(status_code=403, detail="Your account is blocked")
    return user


def get_all_users(db):
    return db.query(User).order_by(User.user_id.desc()).all()


def _check_is_admin(db, admin_id):
    """Small helper used by the two functions below.
    Stops here (raises an error) if the caller isn't an admin."""
    admin = db.query(User).filter(User.user_id == admin_id).first()
    if not admin or admin.role != "ADMIN" or admin.status != "ACTIVE":
        raise HTTPException(status_code=403, detail="Only an admin can do this")


def add_user(db, admin_id, name, email, phone, password, role):
    _check_is_admin(db, admin_id)

    existing = db.query(User).filter(User.email == email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    new_user = User(name=name, email=email, phone=phone, password=password, role=role)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


def set_user_status(db, admin_id, user_id, status):
    _check_is_admin(db, admin_id)

    if status not in ("ACTIVE", "BLOCKED"):
        raise HTTPException(status_code=400, detail="status must be ACTIVE or BLOCKED")

    user = db.query(User).filter(User.user_id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.status = status
    db.commit()
    return user
