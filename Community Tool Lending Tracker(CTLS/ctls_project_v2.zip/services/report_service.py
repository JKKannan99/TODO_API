"""
report_service.py
------------------
Two kinds of reports:
 1. get_summary() - plain numbers for the dashboard boxes.
 2. the chart_* functions - each builds one PNG image using
    Pandas (to read/shape the data) and Matplotlib (to draw it).

The chart functions use pandas.read_sql() directly against the
database engine because that's the simplest way to hand a whole
table straight to Pandas - no need to convert ORM objects by hand.
"""

import io
import pandas as pd
import matplotlib
matplotlib.use("Agg")   # no GUI needed, we only save images
import matplotlib.pyplot as plt
from sqlalchemy import func

from db import engine
from models import Tool, Rental, DamageReport


def get_summary(db):
    total_tools = db.query(Tool).filter(Tool.status != "DELETED").count()

    available_units = db.query(func.coalesce(func.sum(Tool.quantity_available), 0)) \
        .filter(Tool.status == "ACTIVE").scalar()

    active_rentals = db.query(Rental).filter(Rental.status == "DELIVERED").count()

    from datetime import date
    overdue = db.query(Rental).filter(
        Rental.status == "DELIVERED",
        Rental.expected_return_date < date.today(),
    ).count()

    open_damage = db.query(DamageReport).filter(DamageReport.resolution_status == "OPEN").count()

    pending_payments = db.query(Rental).filter(Rental.payment_status != "PAID").count()

    return {
        "total_tools": total_tools,
        "available_units": available_units,
        "active_rentals": active_rentals,
        "overdue": overdue,
        "open_damage_reports": open_damage,
        "pending_payments": pending_payments,
    }


# ---------------------------------------------------------------
# chart helpers
# ---------------------------------------------------------------

def _fig_to_bytes(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    return buf.getvalue()


def _empty(ax):
    ax.text(0.5, 0.5, "No data yet", ha="center")


# 1. MOST BORROWED TOOLS - Bar chart -----------------------------
def most_borrowed_tools_chart():
    query = """
        SELECT t.tool_name, COUNT(r.rental_id) AS times_rented
        FROM rentals r
        JOIN tools t ON t.tool_id = r.tool_id
        GROUP BY t.tool_name
        ORDER BY times_rented DESC
        LIMIT 10
    """
    df = pd.read_sql(query, engine)

    fig, ax = plt.subplots(figsize=(7, 5))
    if df.empty:
        _empty(ax)
    else:
        ax.bar(df["tool_name"], df["times_rented"], color="#4C72B0")
        ax.set_xlabel("Tool")
        ax.set_ylabel("Times Rented")
        ax.set_title("Most Borrowed Tools")
        plt.xticks(rotation=30, ha="right")
    return _fig_to_bytes(fig)


# 2. CATEGORY-WISE BORROWING - Horizontal bar ----------------------
def category_wise_chart():
    query = """
        SELECT c.category_name, COUNT(r.rental_id) AS total_rentals
        FROM rentals r
        JOIN tools t ON t.tool_id = r.tool_id
        JOIN tool_categories c ON c.category_id = t.category_id
        GROUP BY c.category_name
        ORDER BY total_rentals DESC
    """
    df = pd.read_sql(query, engine)

    fig, ax = plt.subplots(figsize=(7, 5))
    if df.empty:
        _empty(ax)
    else:
        ax.barh(df["category_name"], df["total_rentals"], color="#55A868")
        ax.set_xlabel("Total Rentals")
        ax.set_title("Category-wise Borrowing")
    return _fig_to_bytes(fig)


# 3. MONTHLY BORROWING - Line chart --------------------------------
def monthly_borrowing_chart():
    df = pd.read_sql("SELECT rental_date FROM rentals", engine)

    fig, ax = plt.subplots(figsize=(7, 5))
    if df.empty:
        _empty(ax)
    else:
        df["rental_date"] = pd.to_datetime(df["rental_date"])
        df["month"] = df["rental_date"].dt.to_period("M").astype(str)
        monthly = df.groupby("month").size().reset_index(name="count")
        ax.plot(monthly["month"], monthly["count"], marker="o", color="#C44E52")
        ax.set_xlabel("Month")
        ax.set_ylabel("Number of Rentals")
        ax.set_title("Monthly Borrowing Trend")
        plt.xticks(rotation=30, ha="right")
    return _fig_to_bytes(fig)


# 4. TOOL STATUS - Pie chart -----------------------------------------
def tool_status_chart():
    df = pd.read_sql("SELECT status, quantity_available FROM tools WHERE status != 'DELETED'", engine)

    fig, ax = plt.subplots(figsize=(6, 6))
    if df.empty:
        _empty(ax)
    else:
        def label(row):
            if row["status"] == "MAINTENANCE":
                return "UNDER MAINTENANCE"
            return "IN STOCK" if row["quantity_available"] > 0 else "OUT OF STOCK"

        df["label"] = df.apply(label, axis=1)
        counts = df["label"].value_counts()
        ax.pie(counts.values, labels=counts.index, autopct="%1.1f%%", startangle=90)
        ax.set_title("Tool Status Distribution")
    return _fig_to_bytes(fig)


# 5. LENDING DURATION - Box plot --------------------------------------
def lending_duration_chart():
    df = pd.read_sql("SELECT rental_date, expected_return_date FROM rentals", engine)

    fig, ax = plt.subplots(figsize=(6, 5))
    if df.empty:
        _empty(ax)
    else:
        df["rental_date"] = pd.to_datetime(df["rental_date"])
        df["expected_return_date"] = pd.to_datetime(df["expected_return_date"])
        df["duration_days"] = (df["expected_return_date"] - df["rental_date"]).dt.days
        ax.boxplot(df["duration_days"].dropna(), vert=True)
        ax.set_ylabel("Duration (days)")
        ax.set_title("Lending Duration Spread")
    return _fig_to_bytes(fig)


# 6. BORROWING vs TOOL CATEGORY - Bubble chart ---------------------------
def borrowing_vs_category_bubble_chart():
    query = """
        SELECT c.category_name,
               COUNT(r.rental_id) AS total_rentals,
               AVG(t.rental_per_day) AS avg_rental
        FROM tools t
        JOIN tool_categories c ON c.category_id = t.category_id
        LEFT JOIN rentals r ON r.tool_id = t.tool_id
        WHERE t.status != 'DELETED'
        GROUP BY c.category_name
    """
    df = pd.read_sql(query, engine)

    fig, ax = plt.subplots(figsize=(7, 5))
    if df.empty:
        _empty(ax)
    else:
        sizes = (df["total_rentals"].fillna(0) + 1) * 200
        ax.scatter(df["category_name"], df["avg_rental"].fillna(0), s=sizes,
                   alpha=0.6, color="#8172B2")
        ax.set_xlabel("Category")
        ax.set_ylabel("Average Rental / Day (Rs)")
        ax.set_title("Borrowing Volume vs Category (bubble = rental count)")
        plt.xticks(rotation=20, ha="right")
    return _fig_to_bytes(fig)
