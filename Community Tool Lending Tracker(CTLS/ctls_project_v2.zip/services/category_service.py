from fastapi import HTTPException
from models import ToolCategory


def add_category(db, category_name, description):
    if not category_name.strip():
        raise HTTPException(status_code=400, detail="Category name is required")

    category = ToolCategory(category_name=category_name.strip(), description=description)
    db.add(category)
    db.commit()
    db.refresh(category)
    return category


def get_all_categories(db):
    return db.query(ToolCategory).all()
