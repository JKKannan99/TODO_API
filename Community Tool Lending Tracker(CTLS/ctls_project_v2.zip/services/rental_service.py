from datetime import date
from fastapi import HTTPException
from models import Rental, Tool

LATE_PENALTY_PER_DAY_PER_UNIT = 10.00


def create_rental(db, tool_id, quantity, client_name, client_address, client_phone,
                   rented_by, expected_return_date, advance_amount):
    if not client_name.strip() or not client_phone.strip():
        raise HTTPException(status_code=400, detail="Client name and phone are required")
    if quantity < 1:
        raise HTTPException(status_code=400, detail="Quantity must be at least 1")

    tool = db.query(Tool).filter(Tool.tool_id == tool_id).first()
    if not tool:
        raise HTTPException(status_code=404, detail="Tool not found")
    if tool.status != "ACTIVE":
        raise HTTPException(status_code=400, detail="This tool is not active right now")
    if tool.quantity_available < quantity:
        raise HTTPException(
            status_code=400,
            detail=f"Only {tool.quantity_available} unit(s) available, cannot rent {quantity}"
        )

    days = (expected_return_date - date.today()).days
    if days < 1:
        days = 1
    rental_amount = float(tool.rental_per_day) * quantity * days

    if rental_amount > 0 and advance_amount >= rental_amount:
        payment_status = "PAID"
    elif advance_amount > 0:
        payment_status = "PARTIAL"
    else:
        payment_status = "PENDING"

    rental = Rental(
        tool_id=tool_id,
        quantity=quantity,
        client_name=client_name.strip(),
        client_address=client_address,
        client_phone=client_phone.strip(),
        rented_by=rented_by,
        expected_return_date=expected_return_date,
        rental_per_day=tool.rental_per_day,
        rental_amount=rental_amount,
        total_amount=rental_amount,
        advance_amount=advance_amount,
        amount_paid=advance_amount,
        payment_status=payment_status,
    )
    db.add(rental)

    tool.quantity_available -= quantity   # take the units out of stock

    db.commit()
    db.refresh(rental)
    return rental


def get_active_rentals(db):
    rentals = db.query(Rental).filter(Rental.status == "DELIVERED").order_by(Rental.rental_id.desc()).all()
    today = date.today()
    for r in rentals:
        r.days_overdue = max(0, (today - r.expected_return_date).days)
    return rentals


def get_overdue_rentals(db):
    today = date.today()
    rentals = db.query(Rental).filter(
        Rental.status == "DELIVERED",
        Rental.expected_return_date < today,
    ).all()
    for r in rentals:
        r.days_overdue = (today - r.expected_return_date).days
    return rentals


def get_rental_by_id(db, rental_id):
    rental = db.query(Rental).filter(Rental.rental_id == rental_id).first()
    if not rental:
        raise HTTPException(status_code=404, detail="Rental not found")
    return rental


def return_rental(db, rental_id, return_condition):
    rental = get_rental_by_id(db, rental_id)
    if rental.status != "DELIVERED":
        raise HTTPException(status_code=400, detail="This rental is already returned")

    today = date.today()
    late_days = max(0, (today - rental.expected_return_date).days)
    penalty = late_days * LATE_PENALTY_PER_DAY_PER_UNIT * rental.quantity
    new_total = float(rental.rental_amount) + penalty

    if new_total > 0 and float(rental.amount_paid) >= new_total:
        payment_status = "PAID"
    elif float(rental.amount_paid) > 0:
        payment_status = "PARTIAL"
    else:
        payment_status = "PENDING"

    rental.actual_return_date = today
    rental.return_condition = return_condition
    rental.penalty_amount = penalty
    rental.total_amount = new_total
    rental.payment_status = payment_status
    rental.status = "RETURNED"

    tool = db.query(Tool).filter(Tool.tool_id == rental.tool_id).first()
    tool.quantity_available += rental.quantity   # units go back in stock
    tool.condition_status = "DAMAGED" if return_condition == "DAMAGED" else "GOOD"

    db.commit()

    message = "Tool returned"
    if late_days:
        message += f" - {late_days} day(s) late, Rs {penalty} penalty added"

    return {
        "message": message,
        "late_days": late_days,
        "penalty": penalty,
        "total_amount": new_total,
    }


def record_payment(db, rental_id, amount):
    if amount <= 0:
        raise HTTPException(status_code=400, detail="Payment amount must be greater than 0")

    rental = get_rental_by_id(db, rental_id)

    rental.amount_paid = float(rental.amount_paid) + amount
    rental.payment_status = "PAID" if float(rental.amount_paid) >= float(rental.total_amount) else "PARTIAL"

    db.commit()
    return rental
