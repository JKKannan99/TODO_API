from models import DamageReport


def report_damage(db, rental_id, reported_by, damage_description, severity, estimated_cost):
    report = DamageReport(
        rental_id=rental_id,
        reported_by=reported_by,
        damage_description=damage_description,
        severity=severity,
        estimated_cost=estimated_cost,
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


def get_all_damage_reports(db):
    return db.query(DamageReport).order_by(DamageReport.damage_id.desc()).all()
