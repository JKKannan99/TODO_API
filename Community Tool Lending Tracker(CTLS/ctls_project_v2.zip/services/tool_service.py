from fastapi import HTTPException
from models import Tool, Rental


def add_tool(db, category_id, tool_name, description, condition_status,
             quantity_total, rental_per_day, location, created_by):
    if not tool_name.strip():
        raise HTTPException(status_code=400, detail="Tool name is required")
    if quantity_total < 1:
        raise HTTPException(status_code=400, detail="Quantity must be at least 1")
    if rental_per_day < 0:
        raise HTTPException(status_code=400, detail="Rental rate cannot be negative")

    tool = Tool(
        category_id=category_id,
        tool_name=tool_name.strip(),
        description=description,
        condition_status=condition_status,
        quantity_total=quantity_total,
        quantity_available=quantity_total,   # every unit starts out available
        rental_per_day=rental_per_day,
        location=location,
        created_by=created_by,
    )
    db.add(tool)
    db.commit()
    db.refresh(tool)
    return tool


def get_tools(db, search="", category_id=0, only_available=False):
    query = db.query(Tool).filter(Tool.status != "DELETED")

    if search:
        query = query.filter(Tool.tool_name.like(f"%{search}%"))
    if category_id:
        query = query.filter(Tool.category_id == category_id)
    if only_available:
        query = query.filter(Tool.quantity_available > 0, Tool.status == "ACTIVE")

    return query.order_by(Tool.tool_id.desc()).all()


def get_tool_by_id(db, tool_id):
    tool = db.query(Tool).filter(Tool.tool_id == tool_id).first()
    if not tool:
        raise HTTPException(status_code=404, detail="Tool not found")
    return tool


def update_tool(db, tool_id, category_id, tool_name, description, condition_status,
                 quantity_total, rental_per_day, location, status):
    tool = get_tool_by_id(db, tool_id)

    if not tool_name.strip():
        raise HTTPException(status_code=400, detail="Tool name is required")

    # if the total quantity changed, shift quantity_available by the same amount
    delta = quantity_total - tool.quantity_total
    new_available = max(0, tool.quantity_available + delta)

    tool.category_id = category_id
    tool.tool_name = tool_name.strip()
    tool.description = description
    tool.condition_status = condition_status
    tool.quantity_total = quantity_total
    tool.quantity_available = new_available
    tool.rental_per_day = rental_per_day
    tool.location = location
    tool.status = status

    db.commit()
    return tool


def delete_tool(db, tool_id):
    tool = get_tool_by_id(db, tool_id)

    history_count = db.query(Rental).filter(Rental.tool_id == tool_id).count()
    if history_count > 0:
        raise HTTPException(
            status_code=400,
            detail=f"Can't delete - this tool has {history_count} rental record(s). "
                   f"Mark it UNDER MAINTENANCE instead, or edit it."
        )

    db.delete(tool)
    db.commit()
