"""
main.py
-------
This file is now intentionally short. All it does is:
 1. Create the database tables (if they don't exist yet)
 2. Register every router (routes/*.py)
 3. Mount the static/ folder (css, js)

All the actual logic lives in services/, and all the actual
table definitions live in models/. This file just connects them.

Run with:
    uvicorn main:app --reload
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from db import engine, Base
import models  # noqa: F401 - importing this registers all tables with Base

from routes import (
    user_routes,
    category_routes,
    tool_routes,
    rental_routes,
    damage_routes,
    report_routes,
    page_routes,
)

# create all tables in MySQL that don't already exist
Base.metadata.create_all(bind=engine)

app = FastAPI(title="CTLS - Community Tool Lending & Sharing System")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# JSON API routes - all grouped under /api
app.include_router(user_routes.router, prefix="/api")
app.include_router(category_routes.router, prefix="/api")
app.include_router(tool_routes.router, prefix="/api")
app.include_router(rental_routes.router, prefix="/api")
app.include_router(damage_routes.router, prefix="/api")
app.include_router(report_routes.router, prefix="/api")

# HTML page routes - no prefix, e.g. /login, /dashboard
app.include_router(page_routes.router)

# serve static/css and static/js
app.mount("/static", StaticFiles(directory="static"), name="static")
