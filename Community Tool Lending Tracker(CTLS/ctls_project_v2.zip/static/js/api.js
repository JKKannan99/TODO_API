// api.js
// Small shared helper used by every page.
// We store the logged-in user in localStorage after login,
// so every page can read who is currently using the app.

const API_BASE = "/api";   // all JSON routes live under /api (see main.py)

function saveCurrentUser(user) {
    localStorage.setItem("ctls_user", JSON.stringify(user));
}

function getCurrentUser() {
    const raw = localStorage.getItem("ctls_user");
    return raw ? JSON.parse(raw) : null;
}

function logout() {
    localStorage.removeItem("ctls_user");
    window.location.href = "/login";
}

// Redirect to login if nobody is logged in. Call this at the
// top of every protected page.
function requireLogin() {
    const user = getCurrentUser();
    if (!user) {
        window.location.href = "/login";
    }
    return user;
}

// Fills in the navbar greeting + role on pages that have
// an element with id="navUserInfo"
function renderNavUser() {
    const user = getCurrentUser();
    const el = document.getElementById("navUserInfo");
    if (el && user) {
        el.textContent = `${user.name} (${user.role})`;
    }
}

function badge(status) {
    return `<span class="badge ${status}">${status}</span>`;
}
