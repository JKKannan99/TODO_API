from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session

from db import get_db
from services import report_service

router = APIRouter()


@router.get("/reports/summary")
def reports_summary(db: Session = Depends(get_db)):
    return report_service.get_summary(db)


@router.get("/charts/most-borrowed")
def chart_most_borrowed():
    return Response(content=report_service.most_borrowed_tools_chart(), media_type="image/png")


@router.get("/charts/category-wise")
def chart_category_wise():
    return Response(content=report_service.category_wise_chart(), media_type="image/png")


@router.get("/charts/monthly-borrowing")
def chart_monthly():
    return Response(content=report_service.monthly_borrowing_chart(), media_type="image/png")


@router.get("/charts/tool-status")
def chart_status():
    return Response(content=report_service.tool_status_chart(), media_type="image/png")


@router.get("/charts/lending-duration")
def chart_duration():
    return Response(content=report_service.lending_duration_chart(), media_type="image/png")


@router.get("/charts/borrowing-vs-category")
def chart_bubble():
    return Response(content=report_service.borrowing_vs_category_bubble_chart(), media_type="image/png")
