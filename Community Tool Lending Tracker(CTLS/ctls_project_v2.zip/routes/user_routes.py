from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel

from db import get_db
from services import user_service

router = APIRouter()


# ---- request bodies the frontend sends us -----------------------

class LoginRequest(BaseModel):
    email: str
    password: str


class AddUserRequest(BaseModel):
    admin_id: int          # who is doing this - must be an ADMIN
    name: str
    email: str
    phone: str
    password: str
    role: str = "MEMBER"


class StatusRequest(BaseModel):
    admin_id: int
    status: str             # ACTIVE or BLOCKED


# ---- routes -------------------------------------------------------

@router.post("/users/login")
def login(data: LoginRequest, db: Session = Depends(get_db)):
    user = user_service.login(db, data.email, data.password)
    return {
        "user_id": user.user_id,
        "name": user.name,
        "email": user.email,
        "role": user.role,
        "status": user.status,
    }


@router.get("/users")
def list_users(db: Session = Depends(get_db)):
    users = user_service.get_all_users(db)
    return [
        {
            "user_id": u.user_id, "name": u.name, "email": u.email,
            "phone": u.phone, "role": u.role, "status": u.status,
        }
        for u in users
    ]


@router.post("/users/add")
def add_user(data: AddUserRequest, db: Session = Depends(get_db)):
    user = user_service.add_user(db, data.admin_id, data.name, data.email,
                                  data.phone, data.password, data.role)
    return {"message": "Member account created", "user_id": user.user_id}


@router.put("/users/{user_id}/status")
def set_status(user_id: int, data: StatusRequest, db: Session = Depends(get_db)):
    user_service.set_user_status(db, data.admin_id, user_id, data.status)
    return {"message": f"User status set to {data.status}"}
