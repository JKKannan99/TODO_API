from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel

from db import get_db
from services import tool_service

router = APIRouter()


class ToolRequest(BaseModel):
    category_id: int
    tool_name: str
    description: str = ""
    condition_status: str = "GOOD"
    quantity_total: int = 1
    rental_per_day: float = 0.0
    location: str = ""
    created_by: int
    status: str = "ACTIVE"


def _tool_to_dict(t):
    """Turns a Tool row (+ its related category/owner) into plain JSON."""
    return {
        "tool_id": t.tool_id,
        "category_id": t.category_id,
        "category_name": t.category.category_name if t.category else None,
        "tool_name": t.tool_name,
        "description": t.description,
        "condition_status": t.condition_status,
        "quantity_total": t.quantity_total,
        "quantity_available": t.quantity_available,
        "rental_per_day": float(t.rental_per_day),
        "location": t.location,
        "status": t.status,
        "added_by_name": t.added_by.name if t.added_by else None,
    }


@router.post("/tools")
def add_tool(data: ToolRequest, db: Session = Depends(get_db)):
    tool_service.add_tool(
        db, data.category_id, data.tool_name, data.description, data.condition_status,
        data.quantity_total, data.rental_per_day, data.location, data.created_by,
    )
    return {"message": "Tool added"}


@router.get("/tools")
def list_tools(search: str = "", category_id: int = 0, only_available: bool = False,
               db: Session = Depends(get_db)):
    tools = tool_service.get_tools(db, search, category_id, only_available)
    return [_tool_to_dict(t) for t in tools]


@router.get("/tools/{tool_id}")
def get_tool(tool_id: int, db: Session = Depends(get_db)):
    tool = tool_service.get_tool_by_id(db, tool_id)
    return _tool_to_dict(tool)


@router.put("/tools/{tool_id}")
def update_tool(tool_id: int, data: ToolRequest, db: Session = Depends(get_db)):
    tool_service.update_tool(
        db, tool_id, data.category_id, data.tool_name, data.description, data.condition_status,
        data.quantity_total, data.rental_per_day, data.location, data.status,
    )
    return {"message": "Tool updated"}


@router.delete("/tools/{tool_id}")
def delete_tool(tool_id: int, db: Session = Depends(get_db)):
    tool_service.delete_tool(db, tool_id)
    return {"message": "Tool deleted"}
