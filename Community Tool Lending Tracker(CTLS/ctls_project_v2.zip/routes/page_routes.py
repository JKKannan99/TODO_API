from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.get("/")
def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"request": request},
    )


@router.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context={"request": request},
    )


@router.get("/dashboard")
def dashboard_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={"request": request},
    )


@router.get("/lending")
def lending_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="lending.html",
        context={"request": request},
    )


@router.get("/users")
def users_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="users.html",
        context={"request": request},
    )


@router.get("/reports")
def reports_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="reports.html",
        context={"request": request},
    )