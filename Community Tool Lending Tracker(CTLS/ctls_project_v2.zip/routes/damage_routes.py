from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel

from db import get_db
from services import damage_service

router = APIRouter()


class DamageRequest(BaseModel):
    rental_id: int
    reported_by: int
    damage_description: str
    severity: str = "MINOR"
    estimated_cost: float = 0.0


@router.post("/damage")
def report_damage(data: DamageRequest, db: Session = Depends(get_db)):
    damage_service.report_damage(
        db, data.rental_id, data.reported_by, data.damage_description,
        data.severity, data.estimated_cost,
    )
    return {"message": "Damage reported"}


@router.get("/damage")
def list_damage_reports(db: Session = Depends(get_db)):
    reports = damage_service.get_all_damage_reports(db)
    return [
        {
            "damage_id": d.damage_id,
            "tool_name": d.rental.tool.tool_name if d.rental and d.rental.tool else None,
            "damage_description": d.damage_description,
            "severity": d.severity,
            "estimated_cost": float(d.estimated_cost),
            "resolution_status": d.resolution_status,
        }
        for d in reports
    ]
