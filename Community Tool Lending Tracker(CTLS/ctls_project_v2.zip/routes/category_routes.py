from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel

from db import get_db
from services import category_service

router = APIRouter()


class CategoryRequest(BaseModel):
    category_name: str
    description: str = ""


@router.post("/categories")
def add_category(data: CategoryRequest, db: Session = Depends(get_db)):
    category_service.add_category(db, data.category_name, data.description)
    return {"message": "Category added"}


@router.get("/categories")
def list_categories(db: Session = Depends(get_db)):
    categories = category_service.get_all_categories(db)
    return [
        {"category_id": c.category_id, "category_name": c.category_name, "description": c.description}
        for c in categories
    ]
