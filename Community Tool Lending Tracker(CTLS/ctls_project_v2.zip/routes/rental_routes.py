from datetime import date
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel

from db import get_db
from services import rental_service

router = APIRouter()


class RentalRequest(BaseModel):
    tool_id: int
    quantity: int = 1
    client_name: str
    client_address: str = ""
    client_phone: str
    rented_by: int
    expected_return_date: date
    advance_amount: float = 0.0


class ReturnRequest(BaseModel):
    return_condition: str = "GOOD"


class PaymentRequest(BaseModel):
    amount: float


def _rental_to_dict(r, include_overdue=False):
    data = {
        "rental_id": r.rental_id,
        "tool_id": r.tool_id,
        "tool_name": r.tool.tool_name if r.tool else None,
        "quantity": r.quantity,
        "client_name": r.client_name,
        "client_address": r.client_address,
        "client_phone": r.client_phone,
        "rental_date": str(r.rental_date),
        "expected_return_date": str(r.expected_return_date),
        "actual_return_date": str(r.actual_return_date) if r.actual_return_date else None,
        "rental_amount": float(r.rental_amount),
        "penalty_amount": float(r.penalty_amount),
        "total_amount": float(r.total_amount),
        "advance_amount": float(r.advance_amount),
        "amount_paid": float(r.amount_paid),
        "payment_status": r.payment_status,
        "status": r.status,
    }
    if include_overdue:
        data["days_overdue"] = getattr(r, "days_overdue", 0)
    return data


@router.post("/rentals")
def create_rental(data: RentalRequest, db: Session = Depends(get_db)):
    rental = rental_service.create_rental(
        db, data.tool_id, data.quantity, data.client_name, data.client_address,
        data.client_phone, data.rented_by, data.expected_return_date, data.advance_amount,
    )
    return {
        "message": "Tool rented to client",
        "rental_id": rental.rental_id,
        "rental_amount": float(rental.rental_amount),
    }


@router.get("/rentals/active")
def active_rentals(db: Session = Depends(get_db)):
    rentals = rental_service.get_active_rentals(db)
    return [_rental_to_dict(r, include_overdue=True) for r in rentals]


@router.get("/rentals/overdue")
def overdue_rentals(db: Session = Depends(get_db)):
    rentals = rental_service.get_overdue_rentals(db)
    return [_rental_to_dict(r, include_overdue=True) for r in rentals]


@router.get("/rentals/{rental_id}")
def get_rental(rental_id: int, db: Session = Depends(get_db)):
    rental = rental_service.get_rental_by_id(db, rental_id)
    return _rental_to_dict(rental)


@router.put("/rentals/{rental_id}/return")
def return_rental(rental_id: int, data: ReturnRequest, db: Session = Depends(get_db)):
    return rental_service.return_rental(db, rental_id, data.return_condition)


@router.put("/rentals/{rental_id}/payment")
def record_payment(rental_id: int, data: PaymentRequest, db: Session = Depends(get_db)):
    rental = rental_service.record_payment(db, rental_id, data.amount)
    return {
        "message": "Payment recorded",
        "amount_paid": float(rental.amount_paid),
        "payment_status": rental.payment_status,
    }
