"""
seed_data.py
------------
Run this ONCE after the tables have been created (i.e. after you
have started the app at least one time with `uvicorn main:app`)
to fill the database with a few sample rows, so the app isn't
empty on first run.

Run with:
    python seed_data.py
"""

from db import SessionLocal
from models import User, ToolCategory, Tool, Rental
from datetime import date, timedelta

db = SessionLocal()

# don't run twice - skip if users already exist
if db.query(User).count() > 0:
    print("Sample data already exists - skipping.")
else:
    admin = User(name="Admin User", email="admin@ctls.com", phone="9999999999",
                 password="admin123", role="ADMIN")
    ravi = User(name="Ravi Kumar", email="ravi@ctls.com", phone="9000000001",
                password="ravi123", role="MEMBER")
    priya = User(name="Priya Sharma", email="priya@ctls.com", phone="9000000002",
                 password="priya123", role="MEMBER")
    db.add_all([admin, ravi, priya])
    db.commit()

    power = ToolCategory(category_name="Power Tools", description="Drills, saws, grinders etc.")
    garden = ToolCategory(category_name="Garden Tools", description="Spades, mowers, trimmers etc.")
    electronics = ToolCategory(category_name="Electronics", description="Projectors, cameras etc.")
    hand = ToolCategory(category_name="Hand Tools", description="Hammers, wrenches etc.")
    db.add_all([power, garden, electronics, hand])
    db.commit()

    drill = Tool(category_id=power.category_id, tool_name="Bosch Drill Machine",
                 description="Cordless drill with battery", condition_status="GOOD",
                 quantity_total=5, quantity_available=5, rental_per_day=50.00,
                 location="Block A", created_by=admin.user_id)
    projector = Tool(category_id=electronics.category_id, tool_name="Epson Projector",
                      description="HD projector with HDMI cable", condition_status="GOOD",
                      quantity_total=2, quantity_available=1, rental_per_day=150.00,
                      location="Block B", created_by=admin.user_id)
    trimmer = Tool(category_id=garden.category_id, tool_name="Garden Trimmer",
                    description="Electric hedge trimmer", condition_status="FAIR",
                    quantity_total=3, quantity_available=3, rental_per_day=40.00,
                    location="Block A", created_by=admin.user_id)
    hammer = Tool(category_id=hand.category_id, tool_name="Claw Hammer",
                  description="Standard hammer", condition_status="GOOD",
                  quantity_total=10, quantity_available=10, rental_per_day=0.00,
                  location="Block C", created_by=admin.user_id)
    grinder = Tool(category_id=power.category_id, tool_name="Angle Grinder",
                   description="4 inch grinder", condition_status="GOOD",
                   quantity_total=4, quantity_available=4, rental_per_day=60.00,
                   location="Block B", created_by=admin.user_id)
    db.add_all([drill, projector, trimmer, hammer, grinder])
    db.commit()

    # one sample rental so the reports page has something to chart
    sample_rental = Rental(
        tool_id=projector.tool_id, quantity=1,
        client_name="Suresh Menon", client_address="MG Road, Kollam", client_phone="9876543210",
        rented_by=ravi.user_id,
        rental_date=date.today() - timedelta(days=3),
        expected_return_date=date.today() - timedelta(days=1),
        rental_per_day=150.00, rental_amount=300.00, total_amount=300.00,
        advance_amount=100.00, amount_paid=100.00, payment_status="PARTIAL",
    )
    db.add(sample_rental)
    db.commit()

    print("Sample data inserted successfully.")

db.close()
