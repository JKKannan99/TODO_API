# CTLS — Layered Architecture Edition

Same rental-shop app as before, restructured to flow
**routes → services → models**, like your ticketing project.

## Folder structure

```
ctls_project_v2/
├── main.py              <- short entry point: wires everything together
├── db.py                <- SQLAlchemy engine/session (like your db.py)
├── seed_data.py          <- run once to insert sample data
├── models/                <- ONE file per table = ONE class = ONE database call point
│   ├── user.py            <- class User(Base): ...
│   ├── category.py        <- class ToolCategory(Base): ...
│   ├── tool.py             <- class Tool(Base): ...
│   ├── rental.py           <- class Rental(Base): ...
│   └── damage.py           <- class DamageReport(Base): ...
├── services/               <- ALL the business logic / rules live here
│   ├── user_service.py     <- login, add_user, set_user_status
│   ├── category_service.py
│   ├── tool_service.py     <- add_tool, update_tool, delete_tool...
│   ├── rental_service.py   <- create_rental, return_rental (penalty math lives here)
│   ├── damage_service.py
│   └── report_service.py   <- summary numbers + all 6 charts
├── routes/                  <- ONLY handles HTTP in/out, calls a service function
│   ├── user_routes.py
│   ├── category_routes.py
│   ├── tool_routes.py
│   ├── rental_routes.py
│   ├── damage_routes.py
│   ├── report_routes.py
│   └── page_routes.py       <- serves the HTML pages (like your agentlogin route)
├── templates/                <- HTML pages (Jinja2), same as your project
│   ├── index.html
│   ├── login.html
│   ├── dashboard.html
│   ├── lending.html
│   ├── users.html
│   └── reports.html
└── static/
    ├── css/style.css
    └── js/api.js
```

## How a request flows (explain this to students)

```
Browser clicks "Rent"
   |
   v
routes/rental_routes.py   @router.post("/rentals")
   |   just reads the request body, calls a service function
   v
services/rental_service.py   create_rental(db, ...)
   |   ALL the real logic: checks stock, does the maths,
   |   decides PAID/PARTIAL/PENDING
   v
models/rental.py + models/tool.py   (SQLAlchemy classes)
   |   db.add(rental) / tool.quantity_available -= qty
   v
MySQL
```

The route never talks to the database directly, and the model
never contains any decision logic - it's just a table
definition. That's the whole point of the split.

## What changed vs the single-file version

- **Raw SQL → SQLAlchemy ORM.** Instead of writing
  `cur.execute("SELECT * FROM tools WHERE ...")` everywhere, each
  table is now a Python class in `models/`, and you query it like
  `db.query(Tool).filter(Tool.tool_id == tool_id).first()`.
  This is exactly the pattern your `Ticket` model used.
- **One big `main.py` → six small route files.** Each route file
  only knows about ONE thing (users, tools, rentals, damage,
  reports, or pages) and is ~30-80 lines.
- **Business logic moved out of routes into `services/`.** For
  example, all the late-penalty maths now lives in one place:
  `services/rental_service.py`, function `return_rental()`.
- **Plain HTML files → Jinja2 templates.** They're served through
  `page_routes.py` instead of being mounted directly as static
  files. The CSS/JS moved into `static/`.
- **`schema.sql` is gone.** SQLAlchemy creates the tables for you
  automatically (`Base.metadata.create_all()` in `main.py`) based
  on the model classes - you never write `CREATE TABLE` by hand.

## Step 1 — Create the (empty) database

You still need MySQL running and an empty database. Run this
once in MySQL Workbench / the `mysql` CLI:

```sql
CREATE DATABASE ctls_db;
```

## Step 2 — Install dependencies

```bash
cd ctls_project_v2
pip install -r requirements.txt
```

Open `db.py` and update the username/password in `DATABASE_URL`
if yours is different from `root` / `root`.

## Step 3 — Start the app (this creates the tables)

```bash
uvicorn main:app --reload
```

The first time this runs, it automatically creates every table
inside `ctls_db` (empty, no sample data yet).

## Step 4 — Load sample data (run once)

In a second terminal, with the server still running:

```bash
python seed_data.py
```

This adds 3 users, 4 categories, 5 tools, and 1 sample rental so
the app and reports page aren't empty.

## Step 5 — Open the app

```
http://127.0.0.1:8000/login
```

| Email             | Password | Role   |
|-------------------|----------|--------|
| admin@ctls.com    | admin123 | ADMIN  |
| ravi@ctls.com     | ravi123  | MEMBER |
| priya@ctls.com    | priya123 | MEMBER |

## Simplifications worth mentioning to students

- Passwords are stored in plain text.
- No JWT/session auth - the logged-in user just sits in the
  browser's `localStorage`, and admin actions trust the
  `admin_id` the browser sends. Your ticketing project's
  `Depends(get_current_user)` pattern would be the natural next
  step to add here.
- CORS is fully open for easy local development.
