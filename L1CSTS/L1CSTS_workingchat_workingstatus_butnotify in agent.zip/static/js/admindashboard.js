/*****************************************************
 * Admin Dashboard – Agent Chat (FINAL FIXED VERSION)
 *****************************************************/

/* ========= GLOBAL STATE ========= */
let socket = null;
let currentTicketId = null;

/* ========= HELPER: STATUS COLORS ========= */
function getStatusClass(status) {
    if (!status) return "bg-dark";
    switch (status.trim()) {
        case "Open": return "bg-info";
        case "In Progress": return "bg-primary";
        case "Resolved": return "bg-success";
        case "Closed": return "bg-secondary";
        default: return "bg-primary";
    }
}

/* ========= 1. LOAD ALL TICKETS ========= */
async function loadAllTickets() {
    const tableBody = document.getElementById("ticketTableBody");
    if (!tableBody) return;

    try {
        const response = await fetch("/api/all-tickets");
        const tickets = await response.json();
        tableBody.innerHTML = "";

        tickets.forEach(ticket => {
            const currentStatus = ticket.status || "Open";
            const isClosed = currentStatus.toLowerCase() === "closed";
            const badgeClass = getStatusClass(currentStatus);

            tableBody.innerHTML += `
                <tr data-id="${ticket.id}">
                    <td><strong>${ticket.id}</strong></td>
                    <td>${ticket.subject}</td>
                    <td>${ticket.type || "General"}</td>
                    <td><span class="badge ${badgeClass}">${currentStatus}</span></td>
                    <td>${new Date(ticket.created_at).toLocaleDateString()}</td>
                    <td>
                        <button class="btn btn-primary btn-sm" onclick="openChat('${ticket.id}')">Chat</button>
                        <button class="btn ${isClosed ? 'btn-secondary' : 'btn-outline-warning'} btn-sm" 
                                onclick="updateStatus('${ticket.id}', '${currentStatus}')" 
                                ${isClosed ? "disabled" : ""}>
                            <i class="bi ${isClosed ? 'bi-lock-fill' : 'bi-arrow-right-circle'}"></i> 
                            ${isClosed ? "Locked" : "Next Phase"}
                        </button>
                    </td>
                </tr>`;
        });
    } catch (err) {
        console.error("Failed to load tickets", err);
    }
}

/* ========= 2. UPDATE TICKET STATUS (Sequential Flow) ========= */
window.updateStatus = async function(ticketId, currentStatus) {
    const statusFlow = {
        "Open": "In Progress",
        "In Progress": "Resolved",
        "Resolved": "Closed"
    };

    const nextStatus = statusFlow[currentStatus];
    if (!nextStatus) return;

    if (nextStatus === "Closed") {
        if (!confirm("Are you sure you want to CLOSE this ticket? This will lock further updates.")) {
            return;
        }
    }

    try {
        const response = await fetch(`/api/tickets/${ticketId}/status`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: nextStatus })
        });

        if (response.ok) {
            // Refresh table to show new status
            loadAllTickets(); 
        } else {
            const errorData = await response.json();
            alert("Error: " + (errorData.detail || "Could not update status"));
        }
    } catch (error) {
        console.error("Error cycling status:", error);
    }
};

/* ========= 3. OPEN CHAT & CONNECT WEBSOCKET ========= */
window.openChat = async function (ticketId) {
    currentTicketId = ticketId;
    document.getElementById("chatPopup").style.display = "block";
    document.getElementById("chatTicketId").innerText = ticketId;
    const chatBox = document.getElementById("chatMessages");
    chatBox.innerHTML = "";

    // Load history
    try {
        const res = await fetch(`/api/messages/${ticketId}`);
        const history = await res.json();
        history.forEach(m => {
            let cleanText = m.content;
            try {
                if (typeof cleanText === "string" && cleanText.startsWith("{")) {
                    const parsed = JSON.parse(cleanText);
                    cleanText = parsed.message || cleanText;
                }
            } catch (e) {}
            appendMessage(m.sender, cleanText);
        });
    } catch (err) {
        console.error("Failed to load history", err);
    }

    // Connect WebSocket
    if (socket) socket.close();
    socket = new WebSocket(`ws://${window.location.host}/ws/chat/${ticketId}/Agent`);
    
    socket.onmessage = (event) => handleIncomingMessage(event.data);
};

/* ========= 4. HANDLE INCOMING MESSAGE (Live) ========= */
function handleIncomingMessage(raw) {
    try {
        const data = JSON.parse(raw);
        
        // 🟢 HANDLE SYSTEM NOTIFICATIONS IN AGENT CHAT WINDOW
        if (data.sender === "System" || data.is_notification) {
            appendMessage("System", data.message);
            // Refresh table background so the status badge updates without page reload
            loadAllTickets(); 
        } else {
            let sender = data.sender || "Customer";
            let message = data.message;

            if (typeof message === "string" && message.startsWith("{")) {
                try {
                    const inner = JSON.parse(message);
                    message = inner.message || message;
                } catch (_) {}
            }
            appendMessage(sender, message);
        }
    } catch {
        appendMessage("Customer", raw);
    }
}

/* ========= 5. SEND MESSAGE ========= */
window.sendMessage = function () {
    const input = document.getElementById("chatInput");
    const text = input.value.trim();

    if (!text || !socket || socket.readyState !== WebSocket.OPEN) return;

    socket.send(JSON.stringify({
        sender: "Agent",
        message: text
    }));

    input.value = "";
};

/* ========= 6. APPEND MESSAGE TO UI ========= */
function appendMessage(sender, text) {
    const box = document.getElementById("chatMessages");
    if (!box) return;

    const msg = document.createElement("div");
    msg.style.cssText = `
        margin-bottom: 8px;
        padding: 8px;
        border-radius: 6px;
        max-width: 80%;
        font-size: 0.9rem;
    `;

    if (sender === "Agent") {
        msg.style.background = "#d1e7dd";
        msg.style.marginLeft = "auto";
        msg.innerHTML = `<strong>You:</strong> ${text}`;
    } else if (sender === "System") {
        msg.style.background = "#fff3cd"; 
        msg.style.margin = "10px auto";
        msg.style.textAlign = "center";
        msg.style.maxWidth = "90%";
        msg.style.border = "1px solid #ffeeba";
        msg.innerHTML = `<em>${text}</em>`;
    } else {
        msg.style.background = "#f8f9fa";
        msg.style.marginRight = "auto";
        msg.style.border = "1px solid #dee2e6";
        msg.innerHTML = `<strong>Customer:</strong> ${text}`;
    }

    box.appendChild(msg);
    box.scrollTop = box.scrollHeight;
}

/* ========= 7. CLOSE CHAT ========= */
window.closeChat = function() {
    document.getElementById("chatPopup").style.display = "none";
    if (socket) socket.close();
};

/* ========= INIT ========= */
window.onload = loadAllTickets;