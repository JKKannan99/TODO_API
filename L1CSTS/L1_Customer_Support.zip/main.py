from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routes.user_route import router as user_router
from routes.agent_route import router as agent_router
from routes.ticket_route import router as ticket_router
from routes.home_route import router as home_router
from routes import agent_ticket

from db import engine, Base


from fastapi.staticfiles import StaticFiles


app = FastAPI()





# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")



Base.metadata.create_all(bind=engine)

# # ---------- CORS CONFIG ----------
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=[
#         "http://127.0.0.1:5500",
#         "http://localhost:5500"
        
#     ],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# ---------- ROUTERS ----------
app.include_router(home_router)
app.include_router(user_router)
app.include_router(agent_router)
app.include_router(ticket_router)
app.include_router(agent_ticket.router)




# ---------- CREATE TABLES ----------
# @app.on_event("startup")
# def create_tables():
#     Base.metadata.create_all(bind=engine)
