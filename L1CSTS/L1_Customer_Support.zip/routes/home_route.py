from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.get("/")
def home_page(req : Request):   
    return templates.TemplateResponse("home.html",{"request": req})


@router.get("/user_login")
def user_login_page(req : Request):   
    return templates.TemplateResponse("user_login.html",{"request": req})


@router.get("/adminlogin")
def user_login_page(req : Request):   
    return templates.TemplateResponse("adminlogin.html",{"request": req})

@router.get("/user_register")
def user_login_page(req : Request):   
    return templates.TemplateResponse("user_register.html",{"request": req})

@router.get("/createticket")
def user_login_page(req : Request):   
    return templates.TemplateResponse("createticket.html",{"request": req})
