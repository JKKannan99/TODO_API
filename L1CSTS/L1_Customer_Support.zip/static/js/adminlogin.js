function logIn(event){
    event.preventDefault();

    const username = document.getElementById("uname").value.trim();
    const password = document.getElementById("pass").value.trim();
    const msg = document.getElementById("msg");

    msg.innerText = "";


    if(!username || !password){
        showInlineError("All fields are required");
        return;
    }


    fetch("http://127.0.0.1:8000/agent/login", {
        method :"POST",
        headers:{
            "Content-Type":"application/json"
        },

        body : JSON.stringify({
            username,
            password,
        })
    })
    .then(async res =>{
        const data = await res.json();

        if(!res.ok){
            
            if(Array.isArray(data.detail)){
                showInlineError(data.detail[0].msg);
                throw "handled";
            }

            if (typeof data.detail === "string") {
                showInlineError(data.detail)
                throw "handled";
            }

            throw "server";

        }
        return data;
    })
    .then(data =>{
        localStorage.setItem("access_token",data.access_token);

        showNotification("success","Agent Login Successfully!..");

        setTimeout(()=>{
            window.location.href ='/templates/admindashboard.html';
        },2000);
    })
    .catch(err => {
        console.error(err);

        if(err === "handled") return;
        showNotification("error","Agent Login Failed!..");
    })
}






function togglePassword() {
    const passwordInput = document.getElementById("pass");
    const icon = document.getElementById("toggleIcon");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        icon.classList.remove("bi-eye");
        icon.classList.add("bi-eye-slash");
    } else {
        passwordInput.type = "password";
        icon.classList.remove("bi-eye-slash");
        icon.classList.add("bi-eye");
    }
}



function showInlineError(message){
    const msg = document.getElementById("msg");

    msg.innerText = message;
    msg.style.color = "red";
    msg.style.opacity = "1";

    setTimeout(()=> {
        msg.style.opacity = '0';
        msg.innerText = "";
    },5000);
}




function showNotification(type, message) {

    const modalEl = document.getElementById("notifyModal");
    const modal = new bootstrap.Modal(modalEl);

    const modalBox = document.getElementById("modalBox");
    const modalMessage = document.getElementById("modalMessage");
    const modalIcon = document.getElementById("modalIcon");

    modalMessage.innerText = message;

    
    
    if (type === "success") {
        modalBox.className = "modal-content text-center p-4 custom-notify border-0";
        modalBox.style.background = "linear-gradient(135deg,#22c55e,#16a34a)";
        modalMessage.style.color ="white";
        modalIcon.className = "bi bi-check-circle-fill fs-1 mb-2 text-white";
    } else {
        modalBox.className ="modal-content text-center p-4 border-0";
        modalBox.style.background = "linear-gradient(135deg,#ef4444,#b91c1c)";
        modalMessage.style.color = "white";
        modalIcon.className = "bi bi-exclamation-circle-fill fs-1 mb-2 text-white";
    }

    modal.show();

    
    setTimeout(() => {
        modal.hide();
    }, 2000);
}



function goBack() {
    window.location.href='/templates/home.html'
}