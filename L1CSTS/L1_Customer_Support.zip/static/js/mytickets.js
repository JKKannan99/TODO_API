// --- LOGIC FOR VIEWING TICKETS ---
const container = document.getElementById('ticketContainer');

if (container) {
    let tickets = JSON.parse(localStorage.getItem('myTickets')) || [];

    if (tickets.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No tickets found.</div>';
    } else {
        tickets.forEach((ticket, index) => {
            const ticketDiv = document.createElement('div');
            ticketDiv.className = 'card mb-3 p-3 shadow-sm';
            
            // Define all allowed statuses
            const statuses = ['Open', 'In Progress', 'Resolved', 'Closed'];
            
            // Create status flow HTML
            let statusHtml = '<div class="status-bar">';
            statuses.forEach(s => {
                let activeClass = (s === ticket.status) ? 'status-active' : '';
                statusHtml += `<span class="status-pill ${activeClass}">${s}</span>`;
            });
            statusHtml += '</div>'; 



            ticketDiv.className = 'col-12 col-md-6 col-lg-4';

            ticketDiv.innerHTML = `
                <div class="card ticket-card h-100 shadow-sm">
                    <div class="card-header bg-primary-blue text-white">
                        <strong>${ticket.id}</strong>
                    </div>

                    <div class="card-body">
                        <h6 class="card-title">${ticket.subject}</h6>
                        <p class="text-muted small mb-2">
                            <i class="bi bi-tag"></i> ${ticket.type}
                        </p>

                        ${statusHtml}

                        <div class="text-center mt-4">
                            <button class="btn btn-outline-primary btn-sm" onclick="openChat('${ticket.id}')">
                                <i class="bi bi-chat-dots"></i> Chat with Agent
                            </button>
                        </div>
                    </div>

                    <div class="card-footer d-flex justify-content-between align-items-center">
                        <span class="badge bg-success">Created Date : ${ticket.date}</span>
        
                    </div>
                </div>
            `;

            container.appendChild(ticketDiv);
        });
    }
}



// Simulate Agent Functionality
// function simulateAgentUpdate(index) {
//     let tickets = JSON.parse(localStorage.getItem('myTickets'));
//     const statuses = ['Open', 'In Progress', 'Resolved', 'Closed'];
    
//     let currentPos = statuses.indexOf(tickets[index].status);
//     if (currentPos < statuses.length - 1) {
//         tickets[index].status = statuses[currentPos + 1];
//         localStorage.setItem('myTickets', JSON.stringify(tickets));
//         location.reload(); // Refresh to show real-time change
//     } else {
//         alert("Ticket is already Closed.");
//     }
// }





// Chat Meassages

let currentTicketId = "";

// Open Chat
function openChat(ticketId) {
    currentTicketId = ticketId;
    document.getElementById("chatPopup").style.display = "block";
        document.getElementById("chatClient").innerText = "Kannan";
    document.getElementById("chatTicketId").innerText = ticketId;
}

// Close Chat
function closeChat() {
    document.getElementById("chatPopup").style.display = "none";
}

// Send Message
function sendMessage() {
    let input = document.getElementById("chatInput");
    let msg = input.value;

    if (msg === "") return;

    let chatBox = document.getElementById("chatMessages");

    // User message
    let userDiv = document.createElement("div");
    userDiv.className = "user-msg";
    userDiv.innerText = msg;
    chatBox.appendChild(userDiv);

    // Fake agent reply
    setTimeout(() => {
        let agentDiv = document.createElement("div");
        agentDiv.className = "agent-msg";
        agentDiv.innerText = "Agent will respond soon 👍";
        chatBox.appendChild(agentDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }, 1000);

    input.value = "";
}






function logout(){
    window.location.href = '/templates/home.html'
}

function goBack() {
    window.location.href='/templates/createticket.html';
}


