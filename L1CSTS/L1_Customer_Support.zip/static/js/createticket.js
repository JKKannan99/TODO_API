const ticketForm = document.getElementById('ticketForm');
const screenshotInput = document.getElementById('screenshots');
const emailInput = document.getElementById("email");


const MAX_FILES = 3;
const MAX_TOTAL_SIZE = 4 * 1024 * 1024; 
const ALLOWED_TYPES = ['image/png', 'image/jpeg'];


(function checkAuth(){
    const token = localStorage.getItem("access_token");
    if(!token){
        alert("Please login first");
        window.location.href = "/L1_Customer_Support/templates/home.html";
    }
})();


window.addEventListener("DOMContentLoaded", ()=>{
    fetchUserEmail();
})



function fetchUserEmail(){
    const token = localStorage.getItem("access_token");

    fetch("http://127.0.0.1:8000/user/me/email", {
        method: "GET",
        headers: {
            "Authorization": `Bearer ${token}`
        }
    })
    .then(res => {
        if(!res.ok) throw new Error("Unauthorized.Please login..");
        return res.json();
    })
    .then(data => {
        emailInput.value = data.email;
    })
    .catch(err =>{
        alert("Session expired, please login again");
        logout();
    });
}




/* 🔹 REAL-TIME IMAGE VALIDATION */
screenshotInput.addEventListener('change', validateImages);

function validateImages() {
    const files = screenshotInput.files;
    let totalSize = 0;

    // Reset error
    hideInlineError();

    if (files.length > MAX_FILES) {
        showInlineError("Maximum 3 screenshots only allowed.");
        return false;
    }

    if(files.length == 0){
        showInlineError("At least 1 screenshot is required");
        screenshotInput.value ="";
        return false;
    }

    for (let file of files) {
        if (!ALLOWED_TYPES.includes(file.type)) {
            showInlineError("Only PNG and JPG images are allowed.");
            screenshotInput.value = "";
            return false;
        }
        totalSize += file.size;
    }

    if (totalSize > MAX_TOTAL_SIZE) {
        showInlineError("Total image size must be less than 4MB.");
        screenshotInput.value = "";
        return false;
    }

    return true;
}






ticketForm.addEventListener('submit', async function (e) {
    e.preventDefault();

    if (!validateImages()) return;

    const token = localStorage.getItem("access_token");
    const formData = new FormData();



    formData.append("category", document.getElementById('issueType').value);
    formData.append("subject", document.getElementById('subject').value);
    formData.append("description", document.getElementById('description').value);
    formData.append("callback_number", document.getElementById('phone').value);



    // append images

    for(let i=0; i < screenshotInput.files.length; i++){
        formData.append("screenshots", screenshotInput.files[i]);
    }


    try{
        const response = await fetch("http://127.0.0.1:8000/user/create-ticket", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${token}`
            },
            body: formData
        });


        let result = null;

        const contentType = response.headers.get("content-type");
        if(contentType && contentType.includes("application/json")){
            result = await response.json();
        }

        if(response.ok){
            showNotification("success",`Ticket created successfully! Ticket ID: ${result.ticket_id}`);
            setTimeout(()=>{
                window.location.href = "/L1_Customer_Support/templates/mytickets.html"
            },2000)
        }
        
        else{
            showNotification("error", result.detail || "Ticket creation failed")
        }
    }catch(error){
        console.error("Error:",error);
        showNotification("error","Server connection failed..");
    }
});




/* 🔹 ERROR HANDLING */

function showInlineError(message){
    const msg = document.getElementById("msg");
    msg.innerText = message;
    msg.style.display = "block";
    msg.style.color = "red";
    msg.style.opacity = "1";

    setTimeout(()=> {
        msg.style.opacity = '0';
        msg.innerText = "";
        msg.style.display = "none";
    }, 5000);
}


function hideInlineError(){
    const msg = document.getElementById("msg");
    msg.innerText = "";
    msg.style.display = "none";
}



function resetTicketForm() {
    document.getElementById('issueType').value = "";
    document.getElementById('subject').value = "";
    document.getElementById('description').value = "";
    document.getElementById('phone').value = "";
    document.getElementById('screenshots').value = "";

    hideInlineError();
}



/* Logout */
function logout() {
    localStorage.removeItem("access_token");
    window.location.href = '/L1_Customer_Support/templates/home.html';
}




function showNotification(type, message) {

    const modalEl = document.getElementById("notifyModal");
    const modal = new bootstrap.Modal(modalEl);

    const modalBox = document.getElementById("modalBox");
    const modalMessage = document.getElementById("modalMessage");
    const modalIcon = document.getElementById("modalIcon");

    modalMessage.innerText = message;

    
    
    if (type === "success") {
        modalBox.className = "modal-content text-center p-4 custom-notify border-0";
        modalBox.style.background = "linear-gradient(135deg,#22c55e,#16a34a)";
        modalMessage.style.color ="white";
        modalIcon.className = "bi bi-check-circle-fill fs-1 mb-2 text-white";
    } else {
        modalBox.className ="modal-content text-center p-4 border-0";
        modalBox.style.background = "linear-gradient(135deg,#ef4444,#b91c1c)";
        modalMessage.style.color = "white";
        modalIcon.className = "bi bi-exclamation-circle-fill fs-1 mb-2 text-white";
    }

    modal.show();

    
    setTimeout(() => {
        window.location.href = "/L1_Customer_Support/templates/mytickets.html";
    }, 2000);
}



