const tickets = [
  {
    key: "BSP-12",
    title: "Lost badge at rocketry convention",
    reporter: "Grace Harris",
    assignee: "William Adams",
    status: "WAITING FOR SUPPORT",
    time: "14m",
    button : `<button>Change Status</button>`
  },
  {
    key: "BSP-11",
    title: "Outlook isn't loading new emails",
    reporter: "Annika Rangarajan",
    assignee: "Stefanie Auer",
    status: "WAITING FOR RESPONSE",
    time: "20m",
    button : `<button>Change Status</button>`
  },
  {
    key: "BSP-08",
    title: "Access to office after hours",
    reporter: "Andres Ramos",
    assignee: "Crystal Wu",
    status: "WAITING FOR SUPPORT",
    time: "45m",
    button : `<button>Change Status</button>`
  },
  {
    key: "BSP-05",
    title: "What is the budget for training?",
    reporter: "Amar Sundaram",
    assignee: "Samuel Hall",
    status: "APPROVED",
    time: "1h",
    button : `<button>Change Status</button>`
  },
  {
    key: "BSP-01",
    title: "Meeting room 7-32 is screen not working",
    reporter: "Zlatica Chalupka",
    assignee: "Molly Clark",
    status: "CLOSED",
    time: "8h 11m",
    button : `<button>Change Status</button>`
  }
];

const table = document.getElementById("ticketTable");

tickets.forEach(ticket => {
  let statusClass = "waiting";
  if (ticket.status.includes("APPROVED")) statusClass = "approval";
  if (ticket.status.includes("CLOSED")) statusClass = "closed";

  table.innerHTML += `
    <tr>
      <td class="fw-semibold text-primary">${ticket.key}</td>
      <td>${ticket.title}</td>
      <td>${ticket.reporter}</td>
      <td>${ticket.assignee}</td>
      <td>
        <span class="badge-status ${statusClass}">
          ${ticket.status}
        </span>
      </td>
      <td>${ticket.time}</td>
      <td>${ticket.button}</td>
    </tr>
  `;
});


function logout(){
    window.location.href = '/templates/adminlogin.html'
}