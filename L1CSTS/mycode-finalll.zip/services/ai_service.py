import os
from groq import Groq
from utils.prompts import SYSTEM_PROMPT

from dotenv import load_dotenv
load_dotenv()

# --------------------------------------------------
# INIT GROQ CLIENT  ( THIS WAS MISSING)
# --------------------------------------------------
client = Groq(api_key=os.getenv("LLM_API_KEY"))

# --------------------------------------------------
#  L1 SUPPORT (RULE-BASED – NEVER FAILS)
# --------------------------------------------------
def handle_l1_support(msg: str):
    msg = msg.lower()

    if "damaged" in msg or "broken" in msg:
        return (
            "💔 **Product Damaged**\n\n"
            "Sorry about that. You can raise a replacement or refund:\n\n"
            "1. Go to **My Orders**\n"
            "2. Select the product\n"
            "3. Click **Return / Replace**\n"
            "4. Choose **Product Damaged**\n"
            "5. Submit the request\n\n"
            "Our team will arrange pickup or replacement.",
            0.95,
            False
        )

    if "return" in msg:
        return (
            "🔁 **Return Product**\n\n"
            "Steps to return:\n\n"
            "1. Go to **My Orders**\n"
            "2. Select the product\n"
            "3. Click **Return / Refund**\n"
            "4. Choose reason\n"
            "5. Confirm pickup\n\n"
            "Refund will be processed after pickup.",
            0.95,
            False
        )

    if "not delivered" in msg or "delivery issue" in msg:
        return (
            "📦 **Order Not Delivered**\n\n"
            "Please follow these steps:\n\n"
            "1. Go to **My Orders**\n"
            "2. Select the order\n"
            "3. Click **Need Help**\n"
            "4. Choose **Delivery Issue**\n\n"
            "Our support team will assist you.",
            0.95,
            False
        )

    if "agent" in msg or "customer care" in msg or "human" in msg:
        return (
            "🎧 **Connect with Support Agent**\n\n"
            "You can talk to a customer support agent by:\n\n"
            "1. Going to **Help Center**\n"
            "2. Selecting your order\n"
            "3. Choosing **Talk to Agent / Chat with Support**\n\n"
            "An agent will assist you shortly.",
            1.0,
            True
        )

    return None


# --------------------------------------------------
#  AI HANDLER (GROQ)
# --------------------------------------------------
def handle_ai(message: str):
    try:
        completion = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": message}
            ],
            temperature=0.2,
            max_completion_tokens=100,
            top_p=1
        )

        reply = completion.choices[0].message.content
        return reply, 0.2, False

    except Exception as e:
        print("Groq error:", e)
        return (
            "Something went wrong while answering. Please try again.",
            0.3,
            False
        )


# --------------------------------------------------
#  MAIN ENTRY POINT
# --------------------------------------------------
def get_ai_reply(message: str):
    l1 = handle_l1_support(message)
    if l1:
        return l1

    return handle_ai(message)

