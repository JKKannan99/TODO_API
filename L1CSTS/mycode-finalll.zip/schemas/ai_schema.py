from pydantic import BaseModel, Field


class AIRequest(BaseModel):
    message: str

class AIResponse(BaseModel):
    reply: str
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    escalate: bool = Field(default=False)

