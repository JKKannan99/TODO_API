let socket = null;
let activeUserChatTicket = null;
let userTypingTimer;

/* ========= AUTH HELPERS ========= */
async function fetchWithRefresh(url, options = {}) {
    let token = localStorage.getItem("access_token");
    if (!token) { logout(); return null; }
    options.headers = options.headers || {};
    options.headers["Authorization"] = `Bearer ${token}`;
    let response = await fetch(url, options);
    if (response.status === 401) {
        const refreshToken = localStorage.getItem("refresh_token");
        if (refreshToken) {
            const formData = new FormData();
            formData.append("refresh_token", refreshToken);
            const res = await fetch("/user/refresh", { method: "POST", body: formData });
            if (res.ok) {
                const data = await res.json();
                localStorage.setItem("access_token", data.access_token);
                if (data.refresh_token) { localStorage.setItem("refresh_token", data.refresh_token); }
                options.headers["Authorization"] = `Bearer ${data.access_token}`;
                return await fetch(url, options);
            }
        }
        logout();
    }
    return response;
}

/* Priority Color Helper */
function getPriorityClass(p) {
    if (p === "High") return "bg-danger";
    if (p === "Medium") return "bg-warning text-dark";
    return "bg-primary";
}

/* ========= LOAD TICKETS ========= */
async function fetchTickets() {
    const grid = document.getElementById("ticketContainer");
    if(!grid) return;
    try {
        const response = await fetchWithRefresh("/api/mytickets");
        if (!response) return;
        const tickets = await response.json();
        grid.innerHTML = "";
        tickets.forEach(t => {
            const status = t.status;
            const priority = t.priority || "Medium";
            const pOpen = status === "Open" ? "bg-info text-white" : "bg-light text-muted";
            const pProgress = status === "In Progress" ? "bg-primary text-white" : "bg-light text-muted";
            const pResolved = status === "Resolved" ? "bg-success text-white" : "bg-light text-muted";
            const pClosed = status === "Closed" ? "bg-danger text-white" : "bg-light text-muted";

            grid.innerHTML += `
            <div class="col-md-6 mb-4">
                <div class="ticket-card p-4 shadow-sm border bg-white rounded-4 position-relative">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h6 class="text-primary fw-bold">${t.ticket_no}</h6>
                            <h5 class="fw-bold">${t.subject}</h5>
                            <span class="badge ${getPriorityClass(priority)} small mb-2">${priority} Priority</span>
                        </div>
                        <button class="btn btn-sm btn-outline-secondary rounded-pill" onclick="viewIssue('${t.ticket_no}')">View</button>
                    </div>
                    <div class="d-flex justify-content-between gap-1 my-4">
                        <span class="badge rounded-pill flex-fill ${pOpen}">Open</span>
                        <span class="badge rounded-pill flex-fill ${pProgress}">In Progress</span>
                        <span class="badge rounded-pill flex-fill ${pResolved}">Resolved</span>
                        <span class="badge rounded-pill flex-fill ${pClosed}">Closed</span>
                    </div>
                    <button class="btn btn-outline-primary w-100 rounded-pill" onclick="openChat('${t.ticket_no}')" ${status === 'Closed' ? 'disabled' : ''}>
                        <i class="bi bi-chat-dots"></i> ${status === 'Closed' ? 'Chat Closed' : 'Open Chat'}
                    </button>
                </div>
            </div>`;
        });
    } catch (e) { console.error(e); }
}

/* ========= VIEW ISSUE ========= */
window.viewIssue = async function(ticketNo) {
    const detailsBody = document.getElementById('issueDetailsBody');
    const modalElement = document.getElementById("viewIssuePopup");
    if (!modalElement || !detailsBody) return;
    modalElement.style.display = "flex";
    detailsBody.innerHTML = '<div class="text-center p-5"><div class="spinner-border text-primary"></div></div>';
    try {
        const response = await fetchWithRefresh(`/api/ticket-details/${ticketNo}`);
        const t = await response.json();
        const priority = t.priority || "Medium";
        let imagesHtml = '', pdfsHtml = '';
        if (t.attachments) {
            t.attachments.forEach(url => {
                if (url.toLowerCase().endsWith('.pdf')) pdfsHtml += `<a href="${url}" target="_blank" class="btn btn-sm btn-outline-danger mb-2 p-2 w-auto d-block"><i class="bi bi-file-earmark-pdf"></i> PDF</a>`;
                else imagesHtml += `<img src="${url}" class="attachment-preview me-2 mb-2" onclick="window.open('${url}', '_blank')">`;
            });
        }
        detailsBody.innerHTML = `
            <div class="row g-3">
                <div class="col-md-4"><label class="detail-label">TICKET</label><p class="fw-bold">${t.ticket_no}</p></div>
                <div class="col-md-4 text-center"><label class="detail-label">PRIORITY</label><br><span class="badge ${getPriorityClass(priority)}">${priority}</span></div>
                <div class="col-md-4 text-end"><label class="detail-label">STATUS</label><br><span class="badge bg-primary text-white">${t.status}</span></div>
                <div class="col-12"><label class="detail-label">SUBJECT</label><h5>${t.subject}</h5></div>
                <div class="col-12"><label class="detail-label">DESCRIPTION</label><div class="bg-light p-3 border rounded">${t.description || 'No description.'}</div></div>
                <div class="col-12 mt-2">${imagesHtml}</div>
                <div class="col-12 mt-2">${pdfsHtml}</div>
            </div>`;
    } catch (e) { detailsBody.innerHTML = "Error loading."; }
};

/* ========= CHAT & TYPING LOGIC ========= */
function handleUserTypingIndicator(sender) {
    const indicator = document.getElementById("typingIndicator");
    if (!indicator) return;
    indicator.innerText = "Agent is typing...";
    clearTimeout(userTypingTimer);
    userTypingTimer = setTimeout(() => { indicator.innerText = ""; }, 3000);
}

window.openChat = async function(ticketNo) {
    activeUserChatTicket = ticketNo;
    const token = localStorage.getItem("access_token");
    document.getElementById("chatPopup").style.display = "flex";
    document.getElementById("chatTicketId").innerText = ticketNo;

    const inputField = document.getElementById("chatInput");
    if (inputField) {
        inputField.oninput = () => {
            if (socket && socket.readyState === WebSocket.OPEN) {
                socket.send(JSON.stringify({ "type": "typing", "sender": "user" }));
            }
        };
    }

    try {
        const res = await fetchWithRefresh(`/api/messages/${ticketNo}`);
        const history = await res.json();
        const chatBody = document.getElementById("chatMessages");
        chatBody.innerHTML = ''; 
        history.forEach(msg => appendChatMessage(msg.sender, msg.content));
    } catch (e) { console.error(e); }

    if (socket) socket.close();
    socket = new WebSocket(`ws://127.0.0.1:8000/ws/chat/${ticketNo}/user?token=${token}`);
    socket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.type === "typing") {
            if (data.sender !== "user") handleUserTypingIndicator(data.sender);
            return;
        }
        if (activeUserChatTicket === ticketNo) {
            if (data.sender !== "user") {
                appendChatMessage(data.sender, data.message || data.content);
                const indicator = document.getElementById("typingIndicator");
                if(indicator) indicator.innerText = "";
            }
        } else {
            showNotification("success", `New message on Ticket ${ticketNo}`);
        }
    };
};

function appendChatMessage(sender, text) {
    const box = document.getElementById("chatMessages");
    if(!box) return;
    const msgDiv = document.createElement("div");
    msgDiv.className = `chat-msg ${(sender === "user" || sender === "You") ? "user-msg" : "agent-msg"}`;
    msgDiv.innerText = text;
    box.appendChild(msgDiv);
    box.scrollTop = box.scrollHeight;
}

window.sendMessage = function() {
    const input = document.getElementById("chatInput");
    if (!input || !input.value.trim() || !socket) return;
    socket.send(JSON.stringify({ "message": input.value.trim() }));
    appendChatMessage("user", input.value.trim());
    input.value = "";
};

/* ========= UI HELPERS ========= */
function showNotification(type, message) {
    const modalEl = document.getElementById("notifyModal");
    if(!modalEl) return;
    const modal = new bootstrap.Modal(modalEl);
    document.getElementById("modalMessage").innerText = message;
    const box = document.getElementById("modalBox");
    box.style.background = type === "success" ? "linear-gradient(135deg,#22c55e,#16a34a)" : "linear-gradient(135deg,#ef4444,#b91c1c)";
    modal.show();
    setTimeout(() => modal.hide(), 2500);
}

window.closeChat = () => { activeUserChatTicket = null; document.getElementById("chatPopup").style.display = "none"; };
window.closeIssueModal = () => document.getElementById("viewIssuePopup").style.display = "none";

window.logout = async function() {
    const refreshToken = localStorage.getItem("refresh_token");
    if (refreshToken) {
        try {
            await fetch(`/user/logout?refresh_token=${encodeURIComponent(refreshToken)}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" }
            });
        } catch (err) { console.error("Logout error:", err); }
    }
    localStorage.clear();
    window.location.href = "/login";
}

window.goBack = () => window.history.back();
document.addEventListener("DOMContentLoaded", fetchTickets);