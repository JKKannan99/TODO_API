


/*****************************************************
 * Customer Dashboard – My Tickets (FINAL COMPLETED)
 *****************************************************/

let currentTicketId = "";
let socket = null;
const clientId = "Kannan"; // Simulated logged-in user

/* ========= HELPER: STATUS COLORS ========= */
function getStatusClass(status) {
    if (!status) return "bg-primary";
    switch (status.trim()) {
        case "Open": return "bg-info";
        case "In Progress": return "bg-primary";
        case "Resolved": return "bg-success";
        case "Closed": return "bg-secondary";
        default: return "bg-primary";
    }
}

/* ========= 1. FETCH TICKETS FROM DB ========= */
async function loadTickets() {
    const container = document.getElementById('ticketContainer');
    if (!container) return;

    try {
        const response = await fetch(`/api/tickets/${clientId}`);
        if (!response.ok) throw new Error("Failed to fetch");
        
        const tickets = await response.json();
        container.innerHTML = ""; 

        if (tickets.length === 0) {
            container.innerHTML = `
                <div class="col-12 text-center mt-5">
                    <div class="alert alert-info">No tickets found for ${clientId}.</div>
                </div>`;
            return;
        }

        tickets.forEach(ticket => {
            const displayType = ticket.type || ticket.issue_type || "General"; 
            const statusClass = getStatusClass(ticket.status);
            
            const ticketDiv = document.createElement('div');
            ticketDiv.className = 'col-12 col-md-6 col-lg-4 mb-3';
            
            // data-id helps update the badge in real-time via WebSockets
            ticketDiv.innerHTML = `
                <div class="card ticket-card h-100 shadow-sm" data-id="${ticket.id}">
                    <div class="card-header bg-primary text-white"><strong>${ticket.id}</strong></div>
                    <div class="card-body">
                        <h6 class="card-title">${ticket.subject}</h6>
                        <p class="text-muted small"><i class="bi bi-tag"></i> ${displayType}</p>
                        <span class="status-badge badge ${statusClass}">${ticket.status}</span>
                        <div class="d-flex justify-content-between mt-3">
                            <button class="btn btn-primary btn-sm" onclick="openChat('${ticket.id}', '${ticket.status}')">
                                <i class="bi bi-chat-dots"></i> Chat
                            </button>
                            <button class="btn btn-outline-info btn-sm" onclick="viewIssue('${ticket.id}')">
                                <i class="bi bi-eye"></i> View Issue
                            </button>
                        </div>
                    </div>
                </div>`;
            container.appendChild(ticketDiv);
        });
    } catch (error) {
        console.error("Error loading tickets:", error);
        container.innerHTML = '<div class="alert alert-danger">Error connecting to server.</div>';
    }
}

/* ========= 2. OPEN CHAT & CONNECT WEBSOCKET ========= */
window.openChat = async function(ticketId, currentStatus) {
    currentTicketId = ticketId;
    document.getElementById("chatPopup").style.display = "block";
    document.getElementById("chatTicketId").innerText = ticketId;
    document.getElementById("chatMessages").innerHTML = "";

    // Lock input if ticket is already closed when opening
    toggleChatInput(currentStatus);

    // Load History
    try {
        const history = await fetch(`/api/messages/${ticketId}`);
        const messages = await history.json();
        messages.forEach(msg => {
            let cleanText = msg.content;
            try {
                if (typeof cleanText === 'string' && cleanText.startsWith('{')) {
                    const parsed = JSON.parse(cleanText);
                    cleanText = parsed.message || cleanText;
                }
            } catch (e) {}
            appendMessage(msg.sender, cleanText);
        });
    } catch (e) { console.error("History error:", e); }

    // Connect WebSocket
    if (socket) socket.close();
    socket = new WebSocket(`ws://${window.location.host}/ws/chat/${ticketId}/Customer`);

    socket.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            
            // Handle System Status Updates
            if (data.sender === "System" || data.is_notification) {
                // 1. Update Badge on Main UI Card
                const ticketCard = document.querySelector(`.card[data-id="${currentTicketId}"]`);
                if (ticketCard) {
                    const badge = ticketCard.querySelector(".status-badge");
                    if (badge) {
                        // Extract status from message format: "Ticket status has been updated to: Closed"
                        const parts = data.message.split(": ");
                        const newStatus = parts[1] || "Open";
                        
                        badge.innerText = newStatus;
                        badge.className = `status-badge badge ${getStatusClass(newStatus)}`;
                        
                        // 2. Real-time Lock Check for Chat Input
                        toggleChatInput(newStatus);
                    }
                }
            }
            appendMessage(data.sender, data.message);
        } catch (e) {
            appendMessage("System", event.data);
        }
    };
};

/* ========= 3. VIEW ISSUE DETAILS (Modal Popup) ========= */
window.viewIssue = async function(ticketId) {
    const modalElement = document.getElementById('viewIssueModal');
    const viewModal = new bootstrap.Modal(modalElement);
    const detailsBody = document.getElementById('issueDetailsBody');
    
    detailsBody.innerHTML = '<div class="text-center"><div class="spinner-border text-primary"></div></div>';
    viewModal.show();

    try {
        const response = await fetch(`/api/ticket-details/${ticketId}`);
        const data = await response.json();

        // 🟢 FIX: Handle different naming from Database
        const id = data.id || data.ticket_id || ticketId;
        const subject = data.subject || data.ticket_subject || "No Subject";
        const status = data.status || "Open";
        const type = data.type || data.issue_type || "General";
        const desc = data.description || data.issue_description || "No description provided.";
        const date = data.created_at || data.date || new Date();

        let imagesHtml = '';
        if (data.attachments && data.attachments.length > 0) {
            imagesHtml = '<div class="mt-3"><h6>Attachments:</h6><div class="d-flex flex-wrap gap-2">';
            data.attachments.forEach(imgUrl => {
                imagesHtml += `<img src="${imgUrl}" class="img-thumbnail" style="max-width: 180px;" onclick="window.open('${imgUrl}')">`;
            });
            imagesHtml += '</div></div>';
        } else {
            imagesHtml = '<p class="text-muted mt-3">No images uploaded.</p>';
        }

        detailsBody.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Ticket ID:</strong> ${id}</p>
                    <p><strong>Status:</strong> <span class="badge ${getStatusClass(status)}">${status}</span></p>
                    <p><strong>Created:</strong> ${new Date(date).toLocaleString()}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Subject:</strong> ${subject}</p>
                    <p><strong>Category:</strong> ${type}</p>
                </div>
            </div>
            <hr>
            <h6>Issue Description:</h6>
            <div class="p-3 bg-light border rounded">${desc}</div>
            ${imagesHtml}
        `;
    } catch (error) {
        detailsBody.innerHTML = '<div class="alert alert-danger">Error fetching data from database.</div>';
    }
};

/* ========= 4. UI HELPERS ========= */

function toggleChatInput(status) {
    const input = document.getElementById("chatInput");
    const sendBtn = document.querySelector("#chatPopup button[onclick='sendMessage()']");
    
    if (status && status.trim() === "Closed") {
        if (input) {
            input.disabled = true;
            input.placeholder = "This ticket is closed.";
        }
        if (sendBtn) sendBtn.disabled = true;
    } else {
        if (input) {
            input.disabled = false;
            input.placeholder = "Type a message...";
        }
        if (sendBtn) sendBtn.disabled = false;
    }
}

function appendMessage(sender, text) {
    const box = document.getElementById("chatMessages");
    if (!box) return;

    const msg = document.createElement("div");
    msg.style.cssText = `
        margin-bottom: 8px;
        padding: 8px;
        border-radius: 6px;
        max-width: 80%;
        font-size: 0.95rem;
    `;

    let displayName = "";
    if (sender === "Agent") {
        displayName = "Agent";
        msg.style.background = "#f8f9fa"; 
        msg.style.marginRight = "auto";
        msg.style.border = "1px solid #dee2e6";
    } else if (sender === "System") {
        displayName = "System";
        msg.style.background = "#fff3cd"; 
        msg.style.margin = "10px auto";
        msg.style.textAlign = "center";
        msg.style.fontSize = "0.85rem";
        msg.style.maxWidth = "90%";
        msg.style.color = "#856404";
    } else {
        displayName = "You"; 
        msg.style.background = "#cfe2ff"; 
        msg.style.marginLeft = "auto";
        msg.style.border = "1px solid #b6d4fe";
    }

    msg.innerHTML = `<strong>${displayName}:</strong> ${text}`;
    box.appendChild(msg);
    box.scrollTop = box.scrollHeight;
}

window.sendMessage = function() {
    const input = document.getElementById("chatInput");
    const text = input.value.trim();
    if (text !== "" && socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({
            sender: "Customer",
            message: text
        }));
        input.value = "";
    }
};

window.closeChat = function() {
    document.getElementById("chatPopup").style.display = "none";
    if (socket) socket.close();
};

/* ========= INIT ========= */
window.onload = loadTickets;
