const ticketForm = document.getElementById('ticketForm');
const screenshotInput = document.getElementById('screenshots');
const imageError = document.getElementById('imageError');

const MAX_FILES = 3;
const MAX_TOTAL_SIZE = 4 * 1024 * 1024; // 4MB
const ALLOWED_TYPES = ['image/png', 'image/jpeg'];

/* 🔹 REAL-TIME IMAGE VALIDATION */
screenshotInput.addEventListener('change', validateImages);

function validateImages() {
    const files = screenshotInput.files;
    let totalSize = 0;

    // Reset error
    hideError();

    if (files.length > MAX_FILES) {
        showError("Maximum 3 screenshots only allowed.");
        screenshotInput.value = "";
        return false;
    }

    for (let file of files) {
        if (!ALLOWED_TYPES.includes(file.type)) {
            showError("Only PNG and JPG images are allowed.");
            screenshotInput.value = "";
            return false;
        }
        totalSize += file.size;
    }

    if (totalSize > MAX_TOTAL_SIZE) {
        showError("Total image size must be less than 4MB.");
        screenshotInput.value = "";
        return false;
    }

    return true;
}

/* 🔹 FORM SUBMIT */
ticketForm.addEventListener('submit', function (e) {
    e.preventDefault();

    if (!validateImages()) return;

    const newTicket = {
        id: 'TKT-' + Math.floor(Math.random() * 1000),
        subject: document.getElementById('subject').value,
        type: document.getElementById('issueType').value,
        status: 'Open',
        date: new Date().toLocaleDateString(),
        screenshotsCount: screenshotInput.files.length
    };

    let tickets = JSON.parse(localStorage.getItem('myTickets')) || [];
    tickets.push(newTicket);
    localStorage.setItem('myTickets', JSON.stringify(tickets));

    alert('Ticket Created Successfully!');
    window.location.href = '/templates/mytickets.html';
});

/* 🔹 ERROR HANDLING */
function showError(msg) {
    imageError.innerText = msg;
    imageError.style.display = "block";
}

function hideError() {
    imageError.innerText = "";
    imageError.style.display = "none";
}

/* Logout */
function logout() {
    window.location.href = '/templates/home.html';
}

