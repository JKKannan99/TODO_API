

from db import SessionLocal
from models.models import Ticket

def seed():
    db = SessionLocal()
    # Force a new ticket if the table was reset
    test_ticket = Ticket(
        id="TKT-101",
        subject="Payment Failed",
        type="Billing",
        status="Open",
        client_id="Kannan"
    )
    db.add(test_ticket)
    db.commit()
    print("Test ticket added successfully!")
    db.close()

seed()