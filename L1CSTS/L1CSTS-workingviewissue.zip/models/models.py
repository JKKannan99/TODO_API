

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from datetime import datetime
from db import Base


from sqlalchemy.orm import relationship

class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(String(50), primary_key=True)
    subject = Column(String(200))
    type = Column(String(100))
    status = Column(String(50), default="Open")
    client_id = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)

    # 🟢 ADD THIS LINE to link the attachments
    attachments = relationship("TicketAttachment", back_populates="ticket", cascade="all, delete-orphan")

class TicketAttachment(Base):
    __tablename__ = "ticket_attachments"
    id = Column(Integer, primary_key=True, index=True)
    # Ensure this ForeignKey type matches Ticket.id (String(50))
    ticket_id = Column(String(50), ForeignKey("tickets.id", ondelete="CASCADE"))
    file_path = Column(String(255), nullable=False)
    file_type = Column(String(50), nullable=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    ticket = relationship("Ticket", back_populates="attachments")

class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(String(50), ForeignKey("tickets.id"))
    sender = Column(String(50)) # 'Customer' or 'Agent'
    content = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)