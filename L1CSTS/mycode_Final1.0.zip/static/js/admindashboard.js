let pendingStatusData = null;
let allTicketsCache = []; // Store tickets here for local filtering

/* ========= AUTH HELPERS ========= */
function getAuthHeader() {
    const token = localStorage.getItem("access_token");
    if (!token) { window.location.href = "/agentlogin"; return null; }
    return { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" };
}

async function fetchWithRefresh(url, options = {}) {
    let headers = getAuthHeader();
    if (!headers) return null;
    options.headers = { ...options.headers, ...headers };
    let response = await fetch(url, options);
    if (response.status === 401) {
        const refreshToken = localStorage.getItem("refresh_token");
        if (refreshToken) {
            const formData = new FormData();
            formData.append("refresh_token", refreshToken);
            const refreshRes = await fetch("/agent/refresh", { method: "POST", body: formData });
            if (refreshRes.ok) {
                const data = await refreshRes.json();
                localStorage.setItem("access_token", data.access_token);
                options.headers["Authorization"] = `Bearer ${data.access_token}`;
                return await fetch(url, options);
            }
        }
        logout(); return null;
    }
    return response;
}

/* Updated Logout Logic */
window.logout = async function() {
    const refreshToken = localStorage.getItem("refresh_token");
    if (refreshToken) {
        try {
            await fetch(`/agent/logout?refresh_token=${encodeURIComponent(refreshToken)}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" }
            });
        } catch (err) {
            console.error("Server logout request failed:", err);
        }
    }
    localStorage.clear();
    window.location.href = "/agentlogin";
}

function getStatusClass(status) {
    switch (status) {
        case "Open": return "bg-info text-dark";
        case "In Progress": return "bg-primary text-white";
        case "Resolved": return "bg-success text-white";
        case "Closed": return "bg-secondary text-white";
        default: return "bg-dark text-white";
    }
}

/* New Priority Helper */
function getPriorityClass(priority) {
    switch (priority) {
        case "High": return "bg-danger";
        case "Medium": return "bg-warning text-dark";
        default: return "bg-primary";
    }
}

/* ========= LOAD TICKETS ========= */
window.loadAllTickets = async function() {
    const tableBody = document.getElementById("ticketTableBody");
    if (!tableBody) return;
    try {
        const response = await fetchWithRefresh("/agent/all-tickets");
        if (!response) return;
        allTicketsCache = await response.json(); 
        allTicketsCache.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        renderTickets(allTicketsCache); 
    } catch (err) { console.error(err); }
}

/* ========= FILTER LOGIC ========= */
window.filterTickets = function() {
    const filterValue = document.getElementById("statusFilter").value;
    if (filterValue === "All") {
        renderTickets(allTicketsCache);
    } else {
        const filtered = allTicketsCache.filter(t => t.status === filterValue);
        renderTickets(filtered);
    }
}

function renderTickets(tickets) {
    const tableBody = document.getElementById("ticketTableBody");
    if (!tableBody) return;
    tableBody.innerHTML = "";
    tickets.forEach(ticket => {
        const status = ticket.status;
        const priority = ticket.priority || "Medium"; // Default
        const isClosed = status.toLowerCase() === "closed";
        let nextStatus = "", btnClass = "";
        if (status === "Open") { nextStatus = "In Progress"; btnClass = "btn-info text-white"; }
        else if (status === "In Progress") { nextStatus = "Resolved"; btnClass = "btn-success"; }
        else if (status === "Resolved") { nextStatus = "Closed"; btnClass = "btn-danger"; }

        tableBody.innerHTML += `
            <tr>
                <td><strong>${ticket.ticket_no}</strong></td>
                <td>${ticket.subject}</td>
                <td>${ticket.issue_type}</td>
                <td>
                    <select class="form-select form-select-sm border-0 fw-bold ${getPriorityClass(priority)}" 
                            onchange="updatePriority('${ticket.ticket_no}', this.value)" style="width:100px;">
                        <option value="Low" ${priority === 'Low' ? 'selected' : ''}>Low</option>
                        <option value="Medium" ${priority === 'Medium' ? 'selected' : ''}>Medium</option>
                        <option value="High" ${priority === 'High' ? 'selected' : ''}>High</option>
                    </select>
                </td>
                <td><span class="badge ${getStatusClass(status)}">${status}</span></td>
                <td>${new Date(ticket.created_at).toLocaleDateString()}</td>
                <td>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary btn-sm rounded-pill" onclick="viewIssue('${ticket.ticket_no}')"><i class="bi bi-eye"></i> View</button>
                        
                    </div>
                </td>
                 <td>
                    <div class="d-flex gap-2">
                        
                        ${!isClosed ? `<button class="btn btn-sm rounded-pill ${btnClass}" onclick="requestStatusChange('${ticket.ticket_no}', '${nextStatus}')">Move to ${nextStatus}</button>` : `<button class="btn btn-sm btn-light border rounded-pill" disabled>Closed</button>`}
                    </div>
                </td>
                <td><button class="btn btn-success btn-sm rounded-pill" onclick="openAgentChat('${ticket.ticket_no}')"><i class="bi bi-chat-dots"></i> Chat</button></td>
            </tr>`;
    });
}

/* ========= UPDATE PRIORITY ========= */
window.updatePriority = async function(ticketNo, newPriority) {
    const res = await fetchWithRefresh(`/api/tickets/${ticketNo}/priority`, { 
        method: "POST", 
        body: JSON.stringify({ priority: newPriority }) 
    });
    if (res && res.ok) {
        showNotification("success", `Ticket ${ticketNo} set to ${newPriority} priority`);
        loadAllTickets(); 
    } else {
        showNotification("error", "Failed to update priority");
    }
};

/* ========= VIEW ISSUE ========= */
window.viewIssue = async function(ticketNo) {
    const detailsBody = document.getElementById('issueDetailsBody');
    const modalElement = document.getElementById("viewIssuePopup");
    if (!modalElement || !detailsBody) return;
    modalElement.style.display = "flex";
    detailsBody.innerHTML = '<div class="text-center p-5"><div class="spinner-border text-primary"></div></div>';
    try {
        const response = await fetchWithRefresh(`/api/ticket-details/${ticketNo}`);
        const t = await response.json();
        let imagesHtml = '', pdfsHtml = '';
        if (t.attachments) {
            t.attachments.forEach(url => {
                if (url.toLowerCase().endsWith('.pdf')) pdfsHtml += `<a href="${url}" target="_blank" class="btn btn-sm btn-outline-danger mb-2 p-2 w-auto d-block"><i class="bi bi-file-earmark-pdf"></i> PDF</a>`;
                else imagesHtml += `<img src="${url}" class="attachment-preview me-2 mb-2" onclick="window.open('${url}', '_blank')">`;
            });
        }
        detailsBody.innerHTML = `<div class="row g-3">
        <div class="col-md-6">
        <label class="detail-label">TICKET</label><p class="fw-bold">${t.ticket_no}</p>
        </div>
        <div class="col-md-6"><label class="detail-label">STATUS</label><br><span class="badge ${getStatusClass(t.status)}">${t.status}</span></div>
        <div class="col-12"><label class="detail-label">SUBJECT</label><h5>${t.subject}</h5></div><div class="col-12"><label class="detail-label">DESCRIPTION</label><div class="bg-light p-3 border rounded">${t.description || 'No description.'}</div></div>
        <div class="col-12 mt-2">${imagesHtml}</div><div class="col-12 mt-2">${pdfsHtml}</div></div>`;
    } catch (e) { detailsBody.innerHTML = "Error loading."; }
};

window.closeIssueModal = () => document.getElementById("viewIssuePopup").style.display = "none";

/* ========= CHAT & TYPING LOGIC ========= */
let agentSocket = null;
let activeAgentChatTicket = null;
let agentTypingTimer;

function handleAgentTypingIndicator(sender) {
    const indicator = document.getElementById("typingIndicator");
    if (!indicator) return;
    indicator.innerText = sender + " is typing...";
    clearTimeout(agentTypingTimer);
    agentTypingTimer = setTimeout(() => { indicator.innerText = ""; }, 3000);
}

window.openAgentChat = async function(ticketNo) {
    activeAgentChatTicket = ticketNo;
    const token = localStorage.getItem("access_token");
    document.getElementById("chatTicketId").innerText = ticketNo;
    document.getElementById("chatPopup").style.display = "block";

    const inputField = document.getElementById("chatInput");
    if (inputField) {
        inputField.oninput = () => {
            if (agentSocket && agentSocket.readyState === WebSocket.OPEN) {
                agentSocket.send(JSON.stringify({ "type": "typing", "sender": "agent" }));
            }
        };
    }

    try {
        const response = await fetchWithRefresh(`/api/messages/${ticketNo}`);
        const history = await response.json();
        const chatBody = document.getElementById("chatMessages");
        chatBody.innerHTML = ''; 
        history.forEach(msg => appendAgentChatMessage(msg.sender, msg.content));
    } catch (err) { console.error(err); }

    if (agentSocket) agentSocket.close();
    agentSocket = new WebSocket(`ws://${window.location.host}/ws/chat/${ticketNo}/agent?token=${token}`);
    
    agentSocket.onmessage = (e) => {
        const data = JSON.parse(e.data);
        if (data.type === "typing") {
            if (data.sender !== "agent") handleAgentTypingIndicator("User");
            return;
        }
        const chatWindow = document.getElementById("chatPopup");
        if (chatWindow.style.display !== "block" || activeAgentChatTicket !== ticketNo) {
            showNotification("success", `New message from User on Ticket ${ticketNo}`);
        } else {
            if (data.sender !== "agent") {
                appendAgentChatMessage(data.sender, data.message || data.content);
                const indicator = document.getElementById("typingIndicator");
                if(indicator) indicator.innerText = "";
            }
        }
    };
};

function appendAgentChatMessage(sender, text) {
    const box = document.getElementById("chatMessages");
    if(!box) return;
    const msgDiv = document.createElement("div");
    msgDiv.className = `chat-msg ${sender === "agent" ? "user-msg" : "agent-msg"}`;
    msgDiv.textContent = text;
    box.appendChild(msgDiv);
    box.scrollTop = box.scrollHeight;
}

window.sendAgentMessage = function() {
    const input = document.getElementById("chatInput");
    if (!input || !input.value.trim() || !agentSocket) return;
    const messageText = input.value.trim();
    agentSocket.send(JSON.stringify({ "message": messageText }));
    appendAgentChatMessage("agent", messageText);
    input.value = "";
};

/* ========= STATUS MODAL & NOTIFICATIONS ========= */
window.requestStatusChange = function(ticketNo, newStatus) {
    pendingStatusData = { ticketNo, newStatus };
    const textEl = document.getElementById("statusConfirmText");
    if (textEl) textEl.innerText = `Confirm changing Ticket ${ticketNo} to ${newStatus}?`;
    const modalEl = document.getElementById('statusConfirmModal');
    if (modalEl) {
        const modal = new bootstrap.Modal(modalEl);
        modal.show();
    }
}

window.confirmStatusUpdate = async function() {
    if(!pendingStatusData) return;
    const { ticketNo, newStatus } = pendingStatusData;
    const res = await fetchWithRefresh(`/api/tickets/${ticketNo}/status`, { method: "POST", body: JSON.stringify({ status: newStatus }) });
    if (res && res.ok) {
        const modalEl = document.getElementById('statusConfirmModal');
        const inst = bootstrap.Modal.getInstance(modalEl);
        if(inst) inst.hide();
        showNotification("success", `Updated to ${newStatus}`);
        loadAllTickets();
    }
}

function showNotification(type, message) {
    const modalEl = document.getElementById("notifyModal");
    if(!modalEl) return;
    const modal = new bootstrap.Modal(modalEl);
    document.getElementById("modalMessage").innerText = message;
    const box = document.getElementById("modalBox");
    box.style.background = type === "success" ? "linear-gradient(135deg,#22c55e,#16a34a)" : "linear-gradient(135deg,#ef4444,#b91c1c)";
    modal.show();
    setTimeout(() => modal.hide(), 2500);
}

window.closeChat = () => { activeAgentChatTicket = null; document.getElementById("chatPopup").style.display = "none"; };

document.addEventListener("DOMContentLoaded", () => {
    const filterDropdown = document.getElementById("statusFilter");
    if (filterDropdown) { filterDropdown.addEventListener("change", filterTickets); }
    loadAllTickets();
});