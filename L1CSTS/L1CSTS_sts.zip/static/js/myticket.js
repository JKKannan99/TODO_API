


// let currentTicketId = "";
// let socket = null;
// const clientId = "Kannan"; // Simulated logged-in user

// // 1. Fetch Tickets from DB on Load

// async function loadTickets() {
//     const container = document.getElementById('ticketContainer');
//     try {
//         const response = await fetch(`/api/tickets/${clientId}`);
//         if (!response.ok) throw new Error("Failed to fetch");
        
//         const tickets = await response.json();
//         container.innerHTML = ""; // Clear the spinner

//         if (tickets.length === 0) {
//             container.innerHTML = `
//                 <div class="col-12 text-center mt-5">
//                     <div class="alert alert-info">No tickets found for ${clientId}.</div>
//                 </div>`;
//             return;
//         }

       

//         // Inside your loadTickets function loop:
// tickets.forEach(ticket => {
//     // This line handles BOTH old and new column names to be safe
//     const displayType = ticket.type || ticket.issue_type || "General"; 
    
//     const ticketDiv = document.createElement('div');
//     ticketDiv.className = 'col-12 col-md-6 col-lg-4 mb-3';
//     ticketDiv.innerHTML = `
//         <div class="card ticket-card h-100 shadow-sm">
//             <div class="card-header bg-primary text-white"><strong>${ticket.id}</strong></div>
//             <div class="card-body">
//                 <h6 class="card-title">${ticket.subject}</h6>
//                 <p class="text-muted small"><i class="bi bi-tag"></i> ${displayType}</p>
//                 <span class="badge bg-info">${ticket.status}</span>
//                 <div class="text-center mt-3">
//                     <button class="btn btn-primary btn-sm" onclick="openChat('${ticket.id}')">
//                         Chat with Agent
//                     </button>
//                 </div>
//             </div>
//         </div>`;
//     container.appendChild(ticketDiv);
// });
//     } catch (error) {
//         console.error("Error loading tickets:", error);
//         container.innerHTML = '<div class="alert alert-danger">Error connecting to server. Make sure FastAPI is running.</div>';
//     }
// }

// // 2. Open Chat & Connect WebSocket
// async function openChat(ticketId) {
//     currentTicketId = ticketId;
//     document.getElementById("chatPopup").style.display = "block";
//     document.getElementById("chatTicketId").innerText = ticketId;
//     document.getElementById("chatMessages").innerHTML = "";

//     // Load History
//     const history = await fetch(`/api/messages/${ticketId}`);
//     const messages = await history.json();
//     messages.forEach(msg => appendMessage(msg.sender, msg.content));

//     // Connect WebSocket
//     if (socket) socket.close();
//     socket = new WebSocket(`ws://${window.location.host}/ws/chat/${ticketId}/Customer`);

//     socket.onmessage = function(event) {
//     try {
//         // Parse the string into a real JavaScript object
//         const data = JSON.parse(event.data);
        
//         // If 'data.message' is somehow STILL a stringified JSON, parse it again
//         let finalMessage = data.message;
//         if (typeof finalMessage === 'string' && finalMessage.startsWith('{')) {
//             const innerData = JSON.parse(finalMessage);
//             finalMessage = innerData.message || finalMessage;
//         }

//         appendMessage(data.sender, finalMessage);
//     } catch (e) {
//         // If it's just a plain string, show it as is
//         appendMessage("System", event.data);
//     }
// };
// }



// /* ========= APPEND MESSAGE TO UI (Customer Side) ========= */
// function appendMessage(sender, text) {
//     const box = document.getElementById("chatMessages");
//     if (!box) return;

//     const msg = document.createElement("div");
//     msg.style.marginBottom = "8px";
//     msg.style.padding = "8px";
//     msg.style.borderRadius = "6px";
//     msg.style.maxWidth = "80%";

//     // Determine the Display Name and Alignment
//     let displayName = "";
//     if (sender === "Agent") {
//         displayName = "Agent";
//         msg.style.background = "#f8f9fa"; // Light grey for Agent
//         msg.style.marginRight = "auto";
//     } else {
//         displayName = "You"; // Change Customer to 'You'
//         msg.style.background = "#cfe2ff"; // Light blue for Customer
//         msg.style.marginLeft = "auto";
//     }

//     msg.innerHTML = `<strong>${displayName}:</strong> ${text}`;
//     box.appendChild(msg);
//     box.scrollTop = box.scrollHeight;
// }

// function sendMessage() {
//     const input = document.getElementById("chatInput");
//     if (input.value.trim() !== "" && socket) {
//         socket.send(input.value);
//         input.value = "";
//     }
// }

// function closeChat() {
//     document.getElementById("chatPopup").style.display = "none";
//     if (socket) socket.close();
// }

// window.onload = loadTickets;

/*****************************************************
 * Customer Dashboard – My Tickets (COMPLETE VERSION)
 *****************************************************/

let currentTicketId = "";
let socket = null;
const clientId = "Kannan"; // Simulated logged-in user

/* ========= HELPER: STATUS COLORS ========= */
function getStatusClass(status) {
    switch (status) {
        case "Open": return "bg-info";
        case "In-Progress": return "bg-warning text-dark";
        case "Resolved": return "bg-success";
        case "Closed": return "bg-secondary";
        default: return "bg-primary";
    }
}

/* ========= 1. FETCH TICKETS FROM DB ========= */
async function loadTickets() {
    const container = document.getElementById('ticketContainer');
    try {
        const response = await fetch(`/api/tickets/${clientId}`);
        if (!response.ok) throw new Error("Failed to fetch");
        
        const tickets = await response.json();
        container.innerHTML = ""; 

        if (tickets.length === 0) {
            container.innerHTML = `
                <div class="col-12 text-center mt-5">
                    <div class="alert alert-info">No tickets found for ${clientId}.</div>
                </div>`;
            return;
        }

        tickets.forEach(ticket => {
            const displayType = ticket.type || ticket.issue_type || "General"; 
            
            const ticketDiv = document.createElement('div');
            ticketDiv.className = 'col-12 col-md-6 col-lg-4 mb-3';
            // Added data-id attribute to the card for easy WebSocket targeting
            ticketDiv.innerHTML = `
                <div class="card ticket-card h-100 shadow-sm" data-id="${ticket.id}">
                    <div class="card-header bg-primary text-white"><strong>${ticket.id}</strong></div>
                    <div class="card-body">
                        <h6 class="card-title">${ticket.subject}</h6>
                        <p class="text-muted small"><i class="bi bi-tag"></i> ${displayType}</p>
                        <span class="status-badge badge ${getStatusClass(ticket.status)}">${ticket.status}</span>
                        <div class="text-center mt-3">
                            <button class="btn btn-primary btn-sm" onclick="openChat('${ticket.id}', '${ticket.status}')">
                                Chat with Agent
                            </button>
                        </div>
                    </div>
                </div>`;
            container.appendChild(ticketDiv);
        });
    } catch (error) {
        console.error("Error loading tickets:", error);
        container.innerHTML = '<div class="alert alert-danger">Error connecting to server. Make sure FastAPI is running.</div>';
    }
}

/* ========= 2. OPEN CHAT & CONNECT WEBSOCKET ========= */
async function openChat(ticketId, currentStatus) {
    currentTicketId = ticketId;
    document.getElementById("chatPopup").style.display = "block";
    document.getElementById("chatTicketId").innerText = ticketId;
    document.getElementById("chatMessages").innerHTML = "";

    // Disable input if ticket is already closed
    toggleChatInput(currentStatus);

    // Load History
    try {
        const history = await fetch(`/api/messages/${ticketId}`);
        const messages = await history.json();
        messages.forEach(msg => {
            // Logic to clean up any JSON strings stored in content
            let cleanText = msg.content;
            try {
                if (typeof cleanText === 'string' && cleanText.startsWith('{')) {
                    const parsed = JSON.parse(cleanText);
                    cleanText = parsed.message || cleanText;
                }
            } catch (e) {}
            appendMessage(msg.sender, cleanText);
        });
    } catch (e) { console.error("History error:", e); }

    // Connect WebSocket
    if (socket) socket.close();
    socket = new WebSocket(`ws://${window.location.host}/ws/chat/${ticketId}/Customer`);

    // Inside your openChat function, update the socket.onmessage:
socket.onmessage = function(event) {
    try {
        const data = JSON.parse(event.data);
        
        // 🟢 HANDLE REAL-TIME STATUS CHANGE
        if (data.type === "STATUS_UPDATE") {
            // 1. Update the badge on the main ticket card
            const ticketCard = document.querySelector(`.card[data-id="${currentTicketId}"]`);
            if (ticketCard) {
                const badge = ticketCard.querySelector(".status-badge") || ticketCard.querySelector(".badge");
                if (badge) {
                    badge.innerText = data.new_status;
                    badge.className = `badge ${getStatusClass(data.new_status)}`;
                }
            }
            // 2. Disable input if status is "Closed"
            if (data.new_status === "Closed") {
                document.getElementById("chatInput").disabled = true;
                document.getElementById("chatInput").placeholder = "Ticket Closed";
            }
        }

        // Display the system message in the chat window
        appendMessage(data.sender, data.message);
    } catch (e) {
        appendMessage("System", event.data);
    }
};
}

/* ========= 3. UI HELPERS ========= */

function toggleChatInput(status) {
    const input = document.getElementById("chatInput");
    const sendBtn = document.querySelector("#chatPopup .btn-success") || document.querySelector("#chatPopup button[onclick='sendMessage()']");
    
    if (status === "Closed") {
        input.disabled = true;
        input.placeholder = "This ticket is closed.";
        if (sendBtn) sendBtn.disabled = true;
    } else {
        input.disabled = false;
        input.placeholder = "Type a message...";
        if (sendBtn) sendBtn.disabled = false;
    }
}

function appendMessage(sender, text) {
    const box = document.getElementById("chatMessages");
    if (!box) return;

    const msg = document.createElement("div");
    msg.style.marginBottom = "8px";
    msg.style.padding = "8px";
    msg.style.borderRadius = "6px";
    msg.style.maxWidth = "80%";

    let displayName = "";
    if (sender === "Agent") {
        displayName = "Agent";
        msg.style.background = "#f8f9fa"; 
        msg.style.marginRight = "auto";
        msg.style.border = "1px solid #dee2e6";
    } else if (sender === "System") {
        displayName = "System";
        msg.style.background = "#fff3cd"; // Yellow for status changes
        msg.style.margin = "5px auto";
        msg.style.fontSize = "0.85rem";
    } else {
        displayName = "You"; 
        msg.style.background = "#cfe2ff"; 
        msg.style.marginLeft = "auto";
        msg.style.border = "1px solid #b6d4fe";
    }

    msg.innerHTML = `<strong>${displayName}:</strong> ${text}`;
    box.appendChild(msg);
    box.scrollTop = box.scrollHeight;
}

function sendMessage() {
    const input = document.getElementById("chatInput");
    const text = input.value.trim();
    if (text !== "" && socket && socket.readyState === WebSocket.OPEN) {
        socket.send(text);
        input.value = "";
    }
}

function closeChat() {
    document.getElementById("chatPopup").style.display = "none";
    if (socket) socket.close();
}

window.onload = loadTickets;