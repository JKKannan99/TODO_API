from sqlalchemy import Column,Integer,String,DateTime, ForeignKey
from datetime import datetime

from sqlalchemy.orm import relationship


from db import Base

from models.users import User


class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True, index=True)
    ticket_no = Column(String(20))
    user_id = Column(String(50))
    issue_type = Column(String(100))
    subject =  Column(String(200))
    description = Column(String(500))
    callback_number = Column(String(15))
    status = Column(String(50), default="Open")
    created_at = Column(DateTime, default=datetime.utcnow)

    attachments = relationship("TicketAttachment", back_populates="ticket", cascade="all, delete-orphan")
    
    



class TicketAttachment(Base):
    __tablename__ = "ticket_attachments"

    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(Integer, ForeignKey("tickets.id", ondelete="CASCADE"))
    file_path = Column(String(255), nullable=False)
    file_type = Column(String(50), nullable=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    ticket = relationship("Ticket", back_populates="attachments")
