from sqlalchemy.orm import Session
from fastapi import HTTPException
from models.users import User

from auth.XSS_sanitize import sanitize_text
from passlib.context import CryptContext
from auth.jwt_utils import create_access_token,verify_password


pass_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
def create_user(db: Session, user):

    existing_user=db.query(User).filter(User.email==user.email).first()

    if existing_user:
        raise HTTPException(status_code=400,detail="email already exist" )

    hashed_password = pass_context.hash(user.password)

    user = User(
        fullname=sanitize_text(user.fullname),
        email=user.email,
        password_hash=hashed_password  
    )

    db.add(user)
    db.commit()
    db.refresh(user)
    return {"message":"Registration successfully..."}


def authenticate_user(db, data):
    user = db.query(User).filter(User.email == data.email).first()

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    if not verify_password(data.password, user.password_hash):
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    token = create_access_token({
        "user_id": user.id,
        "role":user.role            # "agent" or "customer"-->  "role(key)":"db.role(value)"
        })

    return {
        "access_token": token,
        "token_type": "bearer"
    }