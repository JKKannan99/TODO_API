
import os
import uuid
from sqlalchemy.orm import Session
from models.tickets import Ticket, TicketAttachment

UPLOAD_DIR = "static/uploads/screenshots"
os.makedirs(UPLOAD_DIR, exist_ok=True)

async def create_new_ticket(db: Session, user_id: str, ticket_data: dict, screenshots: list):
    # 1. Generate a unique ticket number
    ticket_no = f"TKT-{uuid.uuid4().hex[:6].upper()}"
    
    # 2. Create the main Ticket record
    new_ticket = Ticket(
        ticket_no=ticket_no,
        user_id=user_id,
        issue_type=ticket_data['category'],
        subject=ticket_data['subject'],
        description=ticket_data['description'],
        callback_number=ticket_data['callback_number']
    )
    db.add(new_ticket)
    db.commit()
    db.refresh(new_ticket)

    # 3. Save each screenshot file and its DB path
    for file in screenshots:
        # Create a unique filename to avoid overwrites
        file_extension = file.filename.split(".")[-1]
        unique_name = f"{uuid.uuid4()}.{file_extension}"
        file_path = os.path.join(UPLOAD_DIR, unique_name)
        
        with open(file_path, "wb") as f:
            f.write(await file.read())
        
        attachment = TicketAttachment(
            ticket_id=new_ticket.id,
            file_path=file_path,
            file_type=file.content_type
        )
        db.add(attachment)
    
    db.commit()
    return new_ticket



