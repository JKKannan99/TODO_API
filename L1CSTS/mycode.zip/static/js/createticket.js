const ticketForm = document.getElementById('ticketForm');
const screenshotInput = document.getElementById('screenshots');
const emailInput = document.getElementById("email");

const MAX_FILES = 3;
const MAX_TOTAL_SIZE = 4 * 1024 * 1024;
const ALLOWED_TYPES = ['image/png', 'image/jpeg'];

let selectedFiles = [];

/* 🔹 AUTH CHECK */
(function checkAuth(){
    const token = localStorage.getItem("access_token");
    if(!token){
        alert("Please login first");
        window.location.href = "/";
    }
})();

/* 🔹 FETCH EMAIL ON LOAD */
window.addEventListener("DOMContentLoaded", ()=>{
    fetchUserEmail();
});



function fetchUserEmail(){
    const token = localStorage.getItem("access_token");

    fetch("http://127.0.0.1:8000/user/me/email", {
        method: "GET",
        headers: {
            "Authorization": `Bearer ${token}`
        }
    })
    .then(res => {
        if(!res.ok) throw new Error("Unauthorized");
        return res.json();
    })
    .then(data => {
        emailInput.value = data.email; // 🔒 email stays, not reset
    })
    .catch(() =>{
        alert("Session expired, please login again");
        logout();
    });
}

/* 🔹 IMAGE VALIDATION */
screenshotInput.addEventListener('change', handleFileSelect);

function handleFileSelect(e) {
    const files = Array.from(e.target.files);

    for (let file of files) {

        if (selectedFiles.length >= MAX_FILES) {
            showInlineError("Maximum 3 screenshots only allowed.");
            break;
        }

        if (!ALLOWED_TYPES.includes(file.type)) {
            showInlineError("Only PNG and JPG images allowed.");
            continue;
        }

        const totalSize =
            selectedFiles.reduce((sum, f) => sum + f.size, 0) + file.size;

        if (totalSize > MAX_TOTAL_SIZE) {
            showInlineError("Total image size must be under 4MB.");
            break;
        }

        if (selectedFiles.some(f => f.name === file.name)) {
            showInlineError("This file already added.");
            continue;
        }

        selectedFiles.push(file);
    }

    updateFileInput();
}

function updateFileInput() {
    const dataTransfer = new DataTransfer();
    selectedFiles.forEach(file => dataTransfer.items.add(file));
    screenshotInput.files = dataTransfer.files;
}

function validateImages() {
    if (selectedFiles.length === 0) {
        showInlineError("Minimum 1 screenshot required.");
        return false;
    }
    return true;
}

/* 🔹 FORM SUBMIT */
ticketForm.addEventListener('submit', async function (e) {
    e.preventDefault();

    if (!validateImages()) return;

    const token = localStorage.getItem("access_token");
    const formData = new FormData();

    formData.append("category", issueType.value);
    formData.append("subject", subject.value);
    formData.append("description", description.value);
    formData.append("callback_number", phone.value);

    selectedFiles.forEach(file => {
        formData.append("screenshots", file);
    });

    

    try {
        const response = await fetch(
            "http://127.0.0.1:8000/user/createticket",
            {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${token}`
                },
                body: formData
            }
        );

        let result = null;
        const contentType = response.headers.get("content-type");

        if (contentType && contentType.includes("application/json")) {
            result = await response.json();
        }

        if (response.ok) {
            showNotification(
                "success",
                `Ticket created successfully! Ticket ID: ${result?.ticket_id || "Generated"}`
            );
        } else {
            showNotification(
                "error",
                result?.detail || "Ticket creation failed"
            );
        }

    } catch (err) {
        console.error(err);
        showNotification("error", "Server connection failed");
    }
});




/* 🔹 INLINE ERROR */
function showInlineError(message){
    const msg = document.getElementById("msg");
    msg.innerText = message;
    msg.style.display = "block";
    msg.style.color = "red";

    setTimeout(()=>{
        msg.innerText = "";
        msg.style.display = "none";
    }, 5000);
}

function hideInlineError(){
    const msg = document.getElementById("msg");
    msg.innerText = "";
    msg.style.display = "none";
}

/* 🔹 RESET (EMAIL NOT TOUCHED) */
function resetTicketForm() {
    issueType.value = "";
    subject.value = "";
    description.value = "";
    phone.value = "";

    selectedFiles = [];
    screenshotInput.value = "";
    hideInlineError();
}

/* 🔹 LOGOUT */
function logout() {
    localStorage.removeItem("access_token");
    window.location.href = "/login"; // Use the route, not the file path
}

/* 🔹 NOTIFICATION (NO MODAL) */
function showNotification(type, message) {
    if (type === "success") {
        const ok = confirm(message);

        if (ok) {
            setTimeout(() => {
                window.location.href =
                    "/user/mytickets";
            }, 0);
        }
    } else {
        alert(message);
    }
}

