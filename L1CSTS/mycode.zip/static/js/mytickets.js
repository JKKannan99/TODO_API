// // --- LOGIC FOR VIEWING TICKETS ---
// const container = document.getElementById('ticketContainer');

// if (container) {
//     let tickets = JSON.parse(localStorage.getItem('myTickets')) || [];

//     if (tickets.length === 0) {
//         container.innerHTML = '<div class="alert alert-info">No tickets found.</div>';
//     } else {
//         tickets.forEach((ticket, index) => {
//             const ticketDiv = document.createElement('div');
//             ticketDiv.className = 'card mb-3 p-3 shadow-sm';
            
//             // Define all allowed statuses
//             const statuses = ['Open', 'In Progress', 'Resolved', 'Closed'];
            
//             // Create status flow HTML
//             let statusHtml = '<div class="status-bar">';
//             statuses.forEach(s => {
//                 let activeClass = (s === ticket.status) ? 'status-active' : '';
//                 statusHtml += `<span class="status-pill ${activeClass}">${s}</span>`;
//             });
//             statusHtml += '</div>'; 



//             ticketDiv.className = 'col-12 col-md-6 col-lg-4';

//             ticketDiv.innerHTML = `
//                 <div class="card ticket-card h-100 shadow-sm">
//                     <div class="card-header bg-primary-blue text-white">
//                         <strong>${ticket.id}</strong>
//                     </div>

//                     <div class="card-body">
//                         <h6 class="card-title">${ticket.subject}</h6>
//                         <p class="text-muted small mb-2">
//                             <i class="bi bi-tag"></i> ${ticket.type}
//                         </p>

//                         ${statusHtml}

//                         <div class="text-center mt-4">
//                             <button class="btn btn-outline-primary btn-sm" onclick="openChat('${ticket.id}')">
//                                 <i class="bi bi-chat-dots"></i> Chat with Agent
//                             </button>
//                         </div>
//                     </div>

//                     <div class="card-footer d-flex justify-content-between align-items-center">
//                         <span class="badge bg-success">Created Date : ${ticket.date}</span>
        
//                     </div>
//                 </div>
//             `;

//             container.appendChild(ticketDiv);
//         });
//     }
// }




// // Chat Meassages

// let currentTicketId = "";

// // Open Chat
// function openChat(ticketId) {
//     currentTicketId = ticketId;
//     document.getElementById("chatPopup").style.display = "block";
//         document.getElementById("chatClient").innerText = "Kannan";
//     document.getElementById("chatTicketId").innerText = ticketId;
// }

// // Close Chat
// function closeChat() {
//     document.getElementById("chatPopup").style.display = "none";
// }

// // Send Message
// function sendMessage() {
//     let input = document.getElementById("chatInput");
//     let msg = input.value;

//     if (msg === "") return;

//     let chatBox = document.getElementById("chatMessages");

//     // User message
//     let userDiv = document.createElement("div");
//     userDiv.className = "user-msg";
//     userDiv.innerText = msg;
//     chatBox.appendChild(userDiv);

//     // Fake agent reply
//     setTimeout(() => {
//         let agentDiv = document.createElement("div");
//         agentDiv.className = "agent-msg";
//         agentDiv.innerText = "Agent will respond soon 👍";
//         chatBox.appendChild(agentDiv);
//         chatBox.scrollTop = chatBox.scrollHeight;
//     }, 1000);

//     input.value = "";
// }






// function logout(){
//     window.location.href = '/templates/home.html'
// }

// function goBack() {
//     window.location.href='/templates/createticket.html';
// }
























let socket = null;
let activeTicket = null;

/* ================= TOKEN ================= */
const token = localStorage.getItem("access_token");

function getRoleFromToken(token) {
    return JSON.parse(atob(token.split(".")[1])).role;
}

if (!token || getRoleFromToken(token) !== "user") {
    alert("Unauthorized");
    location.href = "user_login.html";
}

/* ================= FETCH TICKETS ================= */
fetch("http://127.0.0.1:8000/user/my-tickets", {
    headers: { Authorization: "Bearer " + token }
})
.then(res => res.json())
.then(data => {
    const grid = document.getElementById("ticketContainer");
    grid.innerHTML = "";

    data.forEach(t => {
        grid.innerHTML += `
        <div class="col-md-4">
            <div class="ticket-card p-3">
                <h6 class="text-primary">${t.ticket_no}</h6>
                <p class="fw-bold mb-1">${t.subject}</p>
                <small class="text-muted">${t.category}</small><br>

                <button class="btn btn-outline-primary btn-sm mt-2"
                    onclick="openChat('${t.ticket_no}')">
                    💬 Open Chat
                </button>
            </div>
        </div>`;
    });
});

/* ================= CHAT ================= */
function openChat(ticketNo) {
    activeTicket = ticketNo;

    document.getElementById("chatPopup").style.display = "block";
    document.getElementById("chatTicketId").innerText = ticketNo;
    document.getElementById("chatMessages").innerHTML = "";

    socket = new WebSocket(
        `ws://127.0.0.1:8000/ws/tickets/${ticketNo}?token=${token}`
    );

    socket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        appendMessage(data.sender, data.content);
    };
}

function closeChat() {
    if (socket) socket.close();
    document.getElementById("chatPopup").style.display = "none";
}

/* ================= SEND MESSAGE ================= */
function sendMessage() {
    const input = document.getElementById("chatInput");
    if (!input.value || !socket) return;

    socket.send(JSON.stringify({
        content: input.value
    }));

    appendMessage("You", input.value);
    input.value = "";
}

/* ================= UI ================= */
function appendMessage(sender, text) {
    const box = document.getElementById("chatMessages");

    const cls = sender === "You" ? "user-msg" : "agent-msg";

    box.innerHTML += `
        <div class="${cls}">
            <b>${sender}:</b> ${text}
        </div>
    `;
    box.scrollTop = box.scrollHeight;
}

function logout() {
    localStorage.clear();
    location.href = "user_login.html";
}

function goBack() {
    location.href = "createticket.html";
}
