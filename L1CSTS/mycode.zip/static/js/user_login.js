// function logIn(event) {
//     event.preventDefault(); 

//     const email = document.getElementById("email").value.trim();
//     const password = document.getElementById("password").value.trim();
//     const msg = document.getElementById("msg");

//     msg.innerText = "";

//     if (!email || !password) {
//         showInlineError("All fields are required");
//         return;
//     }

//     fetch("http://127.0.0.1:8000/user/login", {
//         method: "POST",
//         headers: {
//             "Content-Type": "application/json"
//         },
//         body: JSON.stringify({ email, password })
//     })
//     .then(async res => {
//         const data = await res.json();

//         if (!res.ok) {
//             if (Array.isArray(data.detail)) {
//                 showInlineError(data.detail[0].msg);
//                 return null;
//             }

//             if (typeof data.detail === "string") {
//                 showInlineError(data.detail);
//                 return null;
//             }

//             showInlineError("Login failed");
//             return null;
//         }

//         return data;
//     })
//     .then(data => {
//         if (!data) return;

//         localStorage.setItem("access_token", data.access_token);
//         showNotification("success", "Login Successfully!..");
//         window.location.href="/createticket";
//     })
//     .catch(err => {
//         console.error("Fetch error:", err);
//         showNotification("error", "Server error. Try again later.");
//     });
// }




// function showInlineError(message){
//     const msg = document.getElementById("msg");

//     msg.innerText = message;
//     msg.style.color = "red";
//     msg.style.opacity = "1";

//     setTimeout(()=> {
//         msg.style.opacity = '0';
//         msg.innerText = "";
//     },5000);
// }



// function togglePassword() {
//     const passwordInput = document.getElementById("password");
//     const icon = document.getElementById("toggleIcon");

//     if (passwordInput.type === "password") {
//         passwordInput.type = "text";
//         icon.classList.remove("bi-eye");
//         icon.classList.add("bi-eye-slash");
//     } else {
//         passwordInput.type = "password";
//         icon.classList.remove("bi-eye-slash");
//         icon.classList.add("bi-eye");
//     }
// }





// function showNotification(type, message) {

//     const modalEl = document.getElementById("notifyModal");
//     const modal = new bootstrap.Modal(modalEl);

//     const modalBox = document.getElementById("modalBox");
//     const modalMessage = document.getElementById("modalMessage");
//     const modalIcon = document.getElementById("modalIcon");

//     modalMessage.innerText = message;

    
    
//     if (type === "success") {
//         modalBox.className = "modal-content text-center p-4 custom-notify border-0";
//         modalBox.style.background = "linear-gradient(135deg,#22c55e,#16a34a)";
//         modalMessage.style.color ="white";
//         modalIcon.className = "bi bi-check-circle-fill fs-1 mb-2 text-white";
//     } else {
//         modalBox.className ="modal-content text-center p-4 border-0";
//         modalBox.style.background = "linear-gradient(135deg,#ef4444,#b91c1c)";
//         modalMessage.style.color = "white";
//         modalIcon.className = "bi bi-exclamation-circle-fill fs-1 mb-2 text-white";
//     }

//     modal.show();

//     // For success, redirect after the modal is visible so the user can see it.
//     // Use a relative path (works with Live Server and most static hosting setups).
//     if (type === "success") {
//         setTimeout(() => {
//             window.location.href = "/createticket";
//         }, 1200);
//         return;
//     }

//     // For errors, auto-hide the modal after a moment.
//     setTimeout(() => {
//         modal.hide();
//     }, 2000);
// }

function logIn(event) {
    event.preventDefault(); 

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const msg = document.getElementById("msg");

    msg.innerText = "";

    if (!email || !password) {
        showInlineError("All fields are required");
        return;
    }

    fetch("http://127.0.0.1:8000/user/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password })
    })
    .then(async res => {
        const data = await res.json();

        if (!res.ok) {
            if (Array.isArray(data.detail)) {
                showInlineError(data.detail[0].msg);
                return null;
            }

            if (typeof data.detail === "string") {
                showInlineError(data.detail);
                return null;
            }

            showInlineError("Login failed");
            return null;
        }

        return data;
    })
    .then(data => {
        if (!data) return;

        localStorage.setItem("access_token", data.access_token);
        showNotification("success", "Login Successfully!..");
        window.location.href = "/createticket";
        
    })
    .catch(err => {
        console.error("Fetch error:", err);
        showNotification("error", "Server error. Try again later.");
    });
}




function showInlineError(message){
    const msg = document.getElementById("msg");

    msg.innerText = message;
    msg.style.color = "red";
    msg.style.opacity = "1";

    setTimeout(()=> {
        msg.style.opacity = '0';
        msg.innerText = "";
    },5000);
}



function togglePassword() {
    const passwordInput = document.getElementById("password");
    const icon = document.getElementById("toggleIcon");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        icon.classList.remove("bi-eye");
        icon.classList.add("bi-eye-slash");
    } else {
        passwordInput.type = "password";
        icon.classList.remove("bi-eye-slash");
        icon.classList.add("bi-eye");
    }
}





function showNotification(type, message) {

    const modalEl = document.getElementById("notifyModal");
    const modal = new bootstrap.Modal(modalEl);

    const modalBox = document.getElementById("modalBox");
    const modalMessage = document.getElementById("modalMessage");
    const modalIcon = document.getElementById("modalIcon");

    modalMessage.innerText = message;

    
    
    if (type === "success") {
        modalBox.className = "modal-content text-center p-4 custom-notify border-0";
        modalBox.style.background = "linear-gradient(135deg,#22c55e,#16a34a)";
        modalMessage.style.color ="white";
        modalIcon.className = "bi bi-check-circle-fill fs-1 mb-2 text-white";
    } else {
        modalBox.className ="modal-content text-center p-4 border-0";
        modalBox.style.background = "linear-gradient(135deg,#ef4444,#b91c1c)";
        modalMessage.style.color = "white";
        modalIcon.className = "bi bi-exclamation-circle-fill fs-1 mb-2 text-white";
    }

    modal.show();

    // For success, redirect after the modal is visible so the user can see it.
    // Use a relative path (works with Live Server and most static hosting setups).

    if (type === "success") {
    setTimeout(() => {
        // This ensures it goes to the FastAPI route, not a local file
        window.location.href = "/createticket"; 
    }, 2000);
    return;
}

    // For errors, auto-hide the modal after a moment.
    setTimeout(() => {
        modal.hide();
    }, 2000);
}
