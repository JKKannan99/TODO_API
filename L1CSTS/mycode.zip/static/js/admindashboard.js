const API = "http://127.0.0.1:8000";
const token = localStorage.getItem("access_token");
let currentTicketId = null;
let chatInterval = null;

/* ROLE CHECK */
function getRole(token) {
  try {
    return JSON.parse(atob(token.split(".")[1])).role;
  } catch {
    return null;
  }
}
if (!token || getRole(token) !== "agent") {
  alert("Unauthorized");
  location.href = "agent_login.html";
}

/* FETCH TICKETS */
fetch(`${API}/agent/tickets`, {
  headers: { Authorization: `Bearer ${token}` },
})
  .then((r) => r.json())
  .then((data) => {
    const tbody = document.querySelector("#agentTable tbody");
    tbody.innerHTML = "";
    data.forEach((t) => {
      tbody.innerHTML += `
<tr>
<td>${t.ticket_no}</td>
<td>${t.user_id}</td>
<td>${t.status}</td>
<td>
<select class="form-select form-select-sm" onchange="updateStatus(${t.id},this.value)">
<option ${t.status == "Open" ? "selected" : ""}>Open</option>
<option ${t.status == "In Progress" ? "selected" : ""}>In Progress</option>
<option ${t.status == "Closed" ? "selected" : ""}>Closed</option>
</select>
</td>
<td>
<button class="btn btn-sm btn-outline-primary"
 onclick="openChat(${t.id})">
 <i class="bi bi-chat-dots"></i>
</button>
</td>
<td>
<button class="btn btn-sm btn-outline-secondary"
 onclick='viewIssue(${JSON.stringify(t)})'>
 <i class="bi bi-eye"></i>
</button>
</td>
</tr>`;
    });
  });

/* CHAT */
function openChat(ticketId) {
  currentTicketId = ticketId;
  document.getElementById("chatModal").style.display = "block";
  loadMessages();
  chatInterval = setInterval(loadMessages, 3000);
}

function closeChat() {
  clearInterval(chatInterval);
  document.getElementById("chatModal").style.display = "none";
}

function loadMessages() {
  fetch(`${API}/chat/${currentTicketId}`, {
    headers: { Authorization: `Bearer ${token}` },
  })
    .then((r) => r.json())
    .then((msgs) => {
      const box = document.getElementById("chatBox");
      box.innerHTML = "";
      msgs.forEach((m) => {
        const div = document.createElement("div");
        div.className = `msg ${m.sender}`;
        div.innerText = m.message;
        box.appendChild(div);
      });
      box.scrollTop = box.scrollHeight;
    });
}

function sendMessage() {
  const text = document.getElementById("chatMessage").value;
  if (!text) return;

  fetch(`${API}/chat/${currentTicketId}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ message: text }),
  }).then(() => {
    document.getElementById("chatMessage").value = "";
    loadMessages();
  });
}

/* ISSUE */
function viewIssue(t) {
  document.getElementById("issueDetails").innerHTML = `
Ticket: ${t.ticket_no}<br>
User: ${t.user_id}<br>
Description: ${t.description}`;
  document.getElementById("issueModal").style.display = "block";
}
function closeIssue() {
  document.getElementById("issueModal").style.display = "none";
}

/* STATUS */
function updateStatus(id, status) {
  fetch(`${API}/agent/tickets/${id}/status?status=${status}`, {
    method: "PUT",
    headers: { Authorization: `Bearer ${token}` },
  });
}

/* LOGOUT */
function logout() {
  localStorage.clear();
  location.href = "adminlogin";
}
