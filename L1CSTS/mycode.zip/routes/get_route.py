from fastapi import APIRouter,Request
from fastapi.templating import Jinja2Templates
from fastapi import Depends
from auth.jwt_utils import get_current_user

router = APIRouter()

templates = Jinja2Templates(directory="templates")


@router.get("/")
def home_page(req : Request):   
    return templates.TemplateResponse("home.html",{"request": req})


@router.get("/login")
def user_login(req : Request):   
    return templates.TemplateResponse("user_login.html",{"request": req})


@router.get("/register")
def user_register(req : Request):   
    return templates.TemplateResponse("user_register.html",{"request": req})

@router.get("/createticket")
def createticket(req : Request):   
    return templates.TemplateResponse("createticket.html",{"request": req})


# @router.get("/mytickets")
# def my_tickets_page(req: Request):   
#     return templates.TemplateResponse("mytickets.html", {"request": req})
from sqlalchemy.orm import Session
from db import get_db
from models.tickets import Ticket
@router.get("/mytickets")
def read_tickets(db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    user_id = str(current_user.get("user_id"))
    tickets = db.query(Ticket).filter(Ticket.user_id == user_id).all()
    return tickets