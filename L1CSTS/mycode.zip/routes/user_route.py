from fastapi import APIRouter, Depends,HTTPException
from sqlalchemy.orm import Session
from models.users import User
from db import get_db
from schemas.users_schema import *
from services import user_service as us

router = APIRouter(prefix="/user")

@router.post("/register")
def register_user(user: UserCreate, db: Session = Depends(get_db)):
    return us.create_user(db, user)

@router.post("/login")
def login_user(data: LoginRequest, db: Session = Depends(get_db)):
    return us.authenticate_user(db, data)   


# Add get_current_user to imports
from auth.jwt_utils import get_current_user 

@router.get("/me/email")
def get_user_email(current_user: dict = Depends(get_current_user), db: Session = Depends(get_db)):
    # current_user comes from the JWT payload
    user = db.query(User).filter(User.id == current_user.get("user_id")).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"email": user.email}

