// --- LOGIC FOR CREATING TICKET ---
const ticketForm = document.getElementById('ticketForm');

if (ticketForm) {
    ticketForm.addEventListener('submit', function(e) {
        e.preventDefault();

        // 1. Create a ticket object
        const newTicket = {
            id: 'TKT-' + Math.floor(Math.random() * 1000),
            subject: document.getElementById('subject').value,
            type: document.getElementById('issueType').value,
            status: 'Open', // Initial Status
            date: new Date().toLocaleDateString()
        };

        // 2. Get existing tickets from LocalStorage or create new array
        let tickets = JSON.parse(localStorage.getItem('myTickets')) || [];
        
        // 3. Add new ticket and save
        tickets.push(newTicket);
        localStorage.setItem('myTickets', JSON.stringify(tickets));

        alert('Ticket Created Successfully!');
        window.location.href = 'tickets.html'; // Redirect to My Tickets
    });
}

// --- LOGIC FOR VIEWING TICKETS ---
const container = document.getElementById('ticketContainer');

if (container) {
    let tickets = JSON.parse(localStorage.getItem('myTickets')) || [];

    if (tickets.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No tickets found.</div>';
    } else {
        tickets.forEach((ticket, index) => {
            const ticketDiv = document.createElement('div');
            ticketDiv.className = 'card mb-3 p-3 shadow-sm';
            
            // Define all allowed statuses
            const statuses = ['Open', 'In Progress', 'Resolved', 'Closed'];
            
            // Create status flow HTML
            let statusHtml = '<div class="status-bar">';
            statuses.forEach(s => {
                let activeClass = (s === ticket.status) ? 'status-active' : '';
                statusHtml += `<span class="status-pill ${activeClass}">${s}</span>`;
            });
            statusHtml += '</div>';

            ticketDiv.innerHTML = `
                <div class="d-flex justify-content-between align-items-center">
                    <h6>${ticket.id}: ${ticket.subject}</h6>
                    <span class="badge bg-secondary">${ticket.date}</span>
                </div>
                <p class="small text-muted mb-2">Type: ${ticket.type}</p>
                ${statusHtml}
                <div class="mt-2">
                    <button class="btn btn-sm btn-dark mt-2" onclick="simulateAgentUpdate(${index})">
                        Simulate Agent: Next Status
                    </button>
                </div>
            `;
            container.appendChild(ticketDiv);
        });
    }
}

// Simulate Agent Functionality
function simulateAgentUpdate(index) {
    let tickets = JSON.parse(localStorage.getItem('myTickets'));
    const statuses = ['Open', 'In Progress', 'Resolved', 'Closed'];
    
    let currentPos = statuses.indexOf(tickets[index].status);
    if (currentPos < statuses.length - 1) {
        tickets[index].status = statuses[currentPos + 1];
        localStorage.setItem('myTickets', JSON.stringify(tickets));
        location.reload(); // Refresh to show real-time change
    } else {
        alert("Ticket is already Closed.");
    }
}