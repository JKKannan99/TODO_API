package com.bankingsystem.bank.controller;

import com.bankingsystem.bank.dto.*;
import com.bankingsystem.bank.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userService;


    @GetMapping("/")
    public String home() {
        return "Banking API is running successfully!";
    }


    @PostMapping("/register")
    public ResponseEntity<ApiResponse> register(
            @Valid @RequestBody RegisterRequest request) {

        ApiResponse response = userService.register(request);

        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }



    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(
            @RequestBody LoginRequest request) {

        ApiResponse response = userService.login(request);

        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }



    @PostMapping("/deposit")
    public ResponseEntity<ApiResponse> deposit(
            @RequestBody TransactionRequest request) {

        ApiResponse response = userService.deposit(request);

        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }



    @PostMapping("/withdraw")
    public ResponseEntity<ApiResponse> withdraw(
            @RequestBody TransactionRequest request) {

        ApiResponse response = userService.withdraw(request);

        if (response.isSuccess()) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body(response);
        }
    }


    @GetMapping("/transactions")
    public List<TransactionResponse> getTransactions() {
        return userService.getTransactionHistory();
    }
}