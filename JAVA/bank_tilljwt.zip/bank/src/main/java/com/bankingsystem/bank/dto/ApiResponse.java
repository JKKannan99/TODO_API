package com.bankingsystem.bank.dto;

import lombok.Data;

@Data
public class ApiResponse {

    private String message;
    private boolean success;
    private String accountNumber;
    private Double balance;
    private String token;

    // Constructor WITHOUT token
    public ApiResponse(String message, boolean success,
                       String accountNumber, Double balance) {
        this.message = message;
        this.success = success;
        this.accountNumber = accountNumber;
        this.balance = balance;

    }

    // Constructor WITH token
    public ApiResponse(String message, boolean success,
                       String accountNumber, Double balance, String token) {
        this.message = message;
        this.success = success;
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.token = token;
    }
}