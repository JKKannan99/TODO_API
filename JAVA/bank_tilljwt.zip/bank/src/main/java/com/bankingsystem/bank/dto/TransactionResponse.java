package com.bankingsystem.bank.dto;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class TransactionResponse {

    private String type;
    private Double amount;
    private Double balance;
    private LocalDateTime transactionTime;

    public TransactionResponse(String type, Double amount,Double balance, LocalDateTime transactionTime) {
        this.type = type;
        this.amount = amount;
        this.balance = balance;
        this.transactionTime = transactionTime;
    }

}