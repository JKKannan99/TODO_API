package com.bankingsystem.bank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.bankingsystem.bank.entity.User;

public interface UserRepository extends JpaRepository <User,Long>{

    User findByUsername(String username);
    User findByAccountNumber(String accountNumber);
}
