package com.bankingsystem.bank.dto;
import lombok.Data;

@Data

public class ApiResponse {

    private String message;
    private boolean success;
    private String accountNumber;
    private Double balance;

    public ApiResponse(String message, boolean success, String accountNumber, Double balance) {
        this.message = message;
        this.success = success;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public Double getBalance() {
        return balance;
    }
}